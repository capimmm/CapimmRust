Option Explicit
Dim sh, fso, here, app, need, q, i, msg, old
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
q = Chr(34)
here = fso.GetParentFolderName(WScript.ScriptFullName)
app = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\capimm-rust"
If Not fso.FolderExists(app) Then fso.CreateFolder app

Function ReadAll(p)
  On Error Resume Next
  ReadAll = Trim(fso.OpenTextFile(p, 1).ReadAll)
End Function

need = True
If fso.FileExists(app & "\capimm-rust.exe") And fso.FileExists(app & "\version.txt") Then
  If ReadAll(here & "\src\version.txt") = ReadAll(app & "\version.txt") Then need = False
End If
If Not fso.FolderExists(here & "\src") Then need = False

If need Then
  If fso.FileExists(app & "\done.txt") Then fso.DeleteFile app & "\done.txt"
  If fso.FileExists(app & "\fail.txt") Then fso.DeleteFile app & "\fail.txt"
  sh.Run q & here & "\src\build.cmd" & q & " " & q & app & q, 0, False
  sh.Popup "Preparando o capimm-rust (so na primeira vez). A janela abre sozinha em instantes...", 4, "capimm-rust", 64
  For i = 1 To 400
    If fso.FileExists(app & "\done.txt") Or fso.FileExists(app & "\fail.txt") Then Exit For
    WScript.Sleep 300
  Next
  If Not fso.FileExists(app & "\done.txt") Then
    msg = ReadAll(app & "\error.txt")
    If Len(msg) > 1500 Then msg = Left(msg, 1500)
    MsgBox "Nao consegui preparar o capimm-rust." & vbCrLf & vbCrLf & msg, 16, "capimm-rust"
    WScript.Quit 1
  End If
End If
' remove a pasta da versao antiga (Pulse), se existir
On Error Resume Next
old = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Pulse"
If fso.FolderExists(old) Then fso.DeleteFolder old, True
On Error GoTo 0
sh.Run q & app & "\capimm-rust.exe" & q, 1, False
