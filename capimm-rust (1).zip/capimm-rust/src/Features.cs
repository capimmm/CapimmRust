using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Threading;
using Microsoft.Win32;

namespace Pulse
{
    // ---------------------------------------------------------------- ilha dinâmica (janela flutuante no topo da tela)
    class IslandWin
    {
        Window w;
        Border pill, fill;
        Grid ctl, host, top;
        TextBlock text;
        System.Windows.Media.ImageBrush brush;
        System.Windows.Shapes.Path playIcon;
        Border[] eq = new Border[3];
        TranslateTransform pillT;
        bool expanded, notifying, shown;
        string baseText = "capimm-rust";
        DispatcherTimer notifyTimer;
        public Action OnPrev, OnNext, OnToggle, OnOpen;
        public bool NotifyActive { get { return notifying; } }

        T F<T>(string n) where T : class { return w.FindName(n) as T; }

        public void Create()
        {
            using (var st = typeof(IslandWin).Assembly.GetManifestResourceStream("Island.xaml"))
                w = (Window)XamlReader.Load(st);
            pill = F<Border>("Pill");
            fill = F<Border>("IFill");
            ctl = F<Grid>("IslandCtl");
            host = F<Grid>("IHost");
            top = F<Grid>("TopRow");
            text = F<TextBlock>("IslandText");
            brush = F<System.Windows.Media.ImageBrush>("IslandBrush");
            playIcon = F<System.Windows.Shapes.Path>("IPlayIcon");
            pillT = F<TranslateTransform>("PillT");
            eq[0] = F<Border>("IE1"); eq[1] = F<Border>("IE2"); eq[2] = F<Border>("IE3");
            w.Left = (SystemParameters.PrimaryScreenWidth - w.Width) / 2;
            w.Top = 0;
            pill.MouseEnter += (s, e) => { expanded = true; Layout(); };
            pill.MouseLeave += (s, e) => { expanded = false; Layout(); };
            top.MouseLeftButtonUp += (s, e) => { if (OnOpen != null) OnOpen(); };
            F<Button>("IPrev").Click += (s, e) => { if (OnPrev != null) OnPrev(); };
            F<Button>("IPlay").Click += (s, e) => { if (OnToggle != null) OnToggle(); };
            F<Button>("INext").Click += (s, e) => { if (OnNext != null) OnNext(); };
            notifyTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(3200) };
            notifyTimer.Tick += (s, e) => { notifyTimer.Stop(); notifying = false; text.Text = baseText; Layout(); };
        }

        void Layout()
        {
            double wd = expanded ? 400 : (notifying ? 360 : 190), ht = expanded ? 100 : 40;
            var ease = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.45 };
            pill.BeginAnimation(FrameworkElement.WidthProperty, new DoubleAnimation(wd, TimeSpan.FromMilliseconds(520)) { EasingFunction = ease });
            pill.BeginAnimation(FrameworkElement.HeightProperty, new DoubleAnimation(ht, TimeSpan.FromMilliseconds(520)) { EasingFunction = ease });
            ctl.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(expanded ? 1 : 0, TimeSpan.FromMilliseconds(expanded ? 380 : 150)) { BeginTime = TimeSpan.FromMilliseconds(expanded ? 120 : 0) });
        }

        public void Update(string title, string artist)
        {
            baseText = title + (string.IsNullOrEmpty(artist) ? "" : " · " + artist);
            if (!notifying) text.Text = baseText;
        }

        public void SetCover(ImageSource img) { brush.ImageSource = img; }

        public void SetPlaying(bool p)
        {
            playIcon.Data = Geometry.Parse(p ? Geo.Pause : Geo.Play);
        }

        public void Progress(double r)
        {
            if (!shown) return;
            fill.Width = Math.Max(0, Math.Min(1, r)) * Math.Max(0, host.ActualWidth);
        }

        public void Eq(bool active, Random rnd)
        {
            if (!shown) return;
            for (int i = 0; i < 3; i++)
                ((ScaleTransform)eq[i].RenderTransform).ScaleY = active ? 0.25 + rnd.NextDouble() * 0.75 : 0.2;
        }

        public void Notify(string t)
        {
            notifying = true;
            text.Text = t;
            notifyTimer.Stop();
            notifyTimer.Start();
            SetShown(true);
            Layout();
        }

        public void SetShown(bool v)
        {
            if (v == shown) return;
            shown = v;
            if (v)
            {
                w.Show();
                pill.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(350)));
                pillT.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(-30, 0, TimeSpan.FromMilliseconds(560)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.6 } });
            }
            else
            {
                var a = new DoubleAnimation(0, TimeSpan.FromMilliseconds(320));
                a.Completed += (s, e) => { if (!shown) w.Hide(); };
                pill.BeginAnimation(UIElement.OpacityProperty, a);
                pillT.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0, -30, TimeSpan.FromMilliseconds(320)));
            }
        }

        public void Close() { try { w.Close(); } catch { } }
    }

    // ---------------------------------------------------------------- recursos extras da janela principal
    partial class MainWin
    {
        int perf;                       // 0 máximo visual, 1 equilibrado, 2 economia
        bool shuffle, islandOn, lyricsOpen, waveIdle;
        int repeat, lrcIdx = -1;
        Item curItem, lyricsFor;
        IslandWin island;
        DispatcherTimer lyricTimer, islandTimer;
        DateTime lastPlay = DateTime.MinValue;
        System.Windows.Shapes.Rectangle[] wave;
        double[] waveH;
        double wavePhase;
        List<LrcLine> lrc;
        List<TextBlock> lrcBlocks;
        Color[] lastPal = { Colors.White, Colors.White, Colors.White };
        AnimationClock spinClock;

        bool suspended;
        bool FxFull { get { return perf == 0; } }

        // pausa animações quando a janela está em segundo plano ou minimizada (menos CPU e bateria)
        void Suspend(bool on)
        {
            if (on == suspended || (on && perf == 2)) return;
            suspended = on;
            if (on)
            {
                foreach (var n in new[] { "G1", "G2", "G3" })
                {
                    var g = F<TranslateTransform>(n);
                    g.BeginAnimation(TranslateTransform.XProperty, null);
                    g.BeginAnimation(TranslateTransform.YProperty, null);
                }
                if (eqTimer != null) eqTimer.Stop();
                try { if (spinClock != null && !spinClock.IsPaused) spinClock.Controller.Pause(); } catch { }
            }
            else
            {
                ApplyPerf();
                OnPlayState();
            }
        }
        bool Cfg(string k, bool d) { return Setup.Get(k, d ? "1" : "0") == "1"; }
        void SetCfg(string k, bool v) { Setup.Set(k, v ? "1" : "0"); }

        void BuildExtras()
        {
            int p;
            int.TryParse(Setup.Get("perf", "1"), out p);
            perf = p;
            islandOn = Cfg("island", true);
            BuildDock();
            BuildSettings();
            BuildLyrics();
            BuildIsland();
            BuildSocial();
            W.Deactivated += delegate { Suspend(true); };
            W.Activated += delegate { Suspend(false); };
            W.StateChanged += delegate { if (W.WindowState == WindowState.Minimized) Suspend(true); };
            var fa = F<RadioButton>("FltAll");
            var ff = F<RadioButton>("FltFull");
            bool of = Cfg("onlyfull", false);
            fa.IsChecked = !of; ff.IsChecked = of;
            fa.Checked += delegate { SetCfg("onlyfull", false); DoSearch(F<TextBox>("SearchBox").Text.Trim()); };
            ff.Checked += delegate { SetCfg("onlyfull", true); DoSearch(F<TextBox>("SearchBox").Text.Trim()); };
            W.PreviewKeyDown += (s, e) =>
            {
                if (Keyboard.FocusedElement is TextBox) return;
                if (e.Key == Key.Space) { Toggle(); e.Handled = true; }
                else if (e.Key == Key.Right && hasSource) { mp.Position += TimeSpan.FromSeconds(10); e.Handled = true; }
                else if (e.Key == Key.Left && hasSource) { mp.Position = mp.Position > TimeSpan.FromSeconds(10) ? mp.Position - TimeSpan.FromSeconds(10) : TimeSpan.Zero; e.Handled = true; }
                else if (e.Key == Key.L) { ToggleLyrics(); e.Handled = true; }
                else if (e.Key == Key.Escape && lyricsOpen) { ToggleLyrics(); e.Handled = true; }
            };
        }

        // ---------------- dock: onda animada, aleatório e repetir
        void BuildDock()
        {
            var hostC = F<Canvas>("WaveHost");
            wave = new System.Windows.Shapes.Rectangle[36];
            waveH = new double[36];
            for (int i = 0; i < 36; i++)
            {
                var r = new System.Windows.Shapes.Rectangle();
                r.Width = 3; r.Height = 22; r.RadiusX = 1.5; r.RadiusY = 1.5;
                r.Fill = new SolidColorBrush(Color.FromArgb(i % 3 == 0 ? (byte)0xFF : (byte)0xB0, 255, 255, 255));
                r.RenderTransformOrigin = new Point(0.5, 0.5);
                r.RenderTransform = new ScaleTransform(1, 0.1);
                Canvas.SetLeft(r, i * 6);
                hostC.Children.Add(r);
                wave[i] = r; waveH[i] = 0.1;
            }
            var vc = F<Grid>("VolClip");
            vc.SizeChanged += (s, e) => { vc.Clip = new RectangleGeometry(new Rect(0, 0, vc.ActualWidth, vc.ActualHeight), 22, 22); };
            F<Button>("BtnShuffle").Click += delegate { shuffle = !shuffle; SetToggle("BtnShuffle", "ShufIcon", shuffle); };
            F<Button>("BtnRepeat").Click += delegate
            {
                repeat = (repeat + 1) % 3;
                SetToggle("BtnRepeat", "RepIcon", repeat > 0);
                F<TextBlock>("RepeatBadge").Text = repeat == 2 ? "1" : "";
            };
        }

        void SetToggle(string btn, string icon, bool on)
        {
            var b = F<Button>(btn);
            b.Background = on ? Brushes.White : new SolidColorBrush(Color.FromArgb(0x20, 255, 255, 255));
            b.Opacity = on ? 1 : 0.55;
            F<System.Windows.Shapes.Path>(icon).Fill = on ? Brushes.Black : Brushes.White;
        }

        void WaveTick()
        {
            if (wave == null) return;
            bool active = playing && perf < 2;
            if (!active && waveIdle) { if (island != null) island.Eq(false, rnd); return; }
            waveIdle = !active;
            wavePhase += 0.42;
            for (int i = 0; i < wave.Length; i++)
            {
                double target = active ? 0.14 + 0.86 * Math.Abs(Math.Sin(wavePhase + i * 0.5)) * (0.45 + 0.55 * rnd.NextDouble()) : 0.1;
                waveH[i] = waveH[i] * 0.55 + target * 0.45;
                ((ScaleTransform)wave[i].RenderTransform).ScaleY = waveH[i];
            }
            if (island != null) island.Eq(active, rnd);
        }

        void OnEnded()
        {
            if (repeat == 2) { try { mp.Position = TimeSpan.Zero; mp.Play(); } catch { } return; }
            if (repeat == 0 && !shuffle && queue.Count > 0 && qi >= queue.Count - 1) { playing = false; UpdateIcon(); return; }
            Next();
        }

        void NextTrack()
        {
            if (queue.Count == 0) return;
            if (shuffle && queue.Count > 1)
            {
                int n;
                do { n = rnd.Next(queue.Count); } while (n == qi);
                qi = n;
            }
            else qi = (qi + 1) % queue.Count;
            PlayItem(queue[qi]);
        }

        // ---------------- capa grande, disco e fundo dinâmico
        void SetCover(Item it)
        {
            curItem = it;
            var brush = F<System.Windows.Media.ImageBrush>("NowCoverBrush");
            var disc = F<System.Windows.Media.ImageBrush>("DiscBrush");
            brush.ImageSource = null;
            disc.ImageSource = null;
            F<TextBlock>("NowGlyph").Visibility = Visibility.Visible;
            F<TextBlock>("DiscGlyph").Visibility = Visibility.Visible;
            F<TextBlock>("FTitle").Text = it.Name;
            F<TextBlock>("FArtist").Text = it.Artist ?? "";
            if (island != null) island.SetCover(null);
            string url = it.CoverBig ?? it.Cover;
            if (string.IsNullOrEmpty(url))
            {
                ApplyPalette(Extra.NamePalette(it.Name));
            }
            else
            {
                int id = playId;
                ThreadPool.QueueUserWorkItem(delegate
                {
                    try
                    {
                        Color[] pal;
                        var img = Extra.LoadImage(url, 500, out pal);
                        Ui(() =>
                        {
                            if (id != playId) return;
                            brush.ImageSource = img;
                            disc.ImageSource = img;
                            F<TextBlock>("NowGlyph").Visibility = Visibility.Collapsed;
                            F<TextBlock>("DiscGlyph").Visibility = Visibility.Collapsed;
                            ApplyPalette(pal);
                            if (island != null) island.SetCover(img);
                        });
                    }
                    catch (Exception ex) { Util.Log(ex); }
                });
            }
            if (Cfg("lyrics", true)) LoadLyrics(it); // já busca a letra para abrir instantâneo
        }

        void ApplyPalette(Color[] p)
        {
            if (p == null || p.Length < 3) return;
            lastPal = p;
            bool dyn = Cfg("bgdyn", true) && perf < 2;
            if (!dyn) p = new[] { Colors.White, Colors.White, Colors.White };
            Fade("G1c", p[0], (byte)(dyn ? 0xA8 : 0x30)); Fade("G1e", p[0], 0);
            Fade("G2c", p[1], (byte)(dyn ? 0x90 : 0x22)); Fade("G2e", p[1], 0);
            Fade("G3c", p[2], (byte)(dyn ? 0x78 : 0x18)); Fade("G3e", p[2], 0);
            Fade("TintT", p[0], (byte)(dyn ? 0x70 : 0)); Fade("TintB", p[1], (byte)(dyn ? 0x34 : 0));
            Fade("LG1c", p[0], (byte)(dyn ? 0x9A : 0)); Fade("LG1e", p[0], 0);
            Fade("LG2c", p[1], (byte)(dyn ? 0x86 : 0)); Fade("LG2e", p[1], 0);
        }

        void Fade(string stop, Color c, byte a)
        {
            var g = F<GradientStop>(stop);
            if (g == null) return;
            g.BeginAnimation(GradientStop.ColorProperty, new ColorAnimation(Color.FromArgb(a, c.R, c.G, c.B), TimeSpan.FromMilliseconds(perf == 2 ? 1 : 1300)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        }

        // ---------------- busca online (fontes ativadas em Ajustes)
        void SearchOnline(string q)
        {
            int id = ++searchId;
            F<TextBlock>("OnlineHeader").Text = q.Length == 0 ? "Em alta agora" : "Resultados online";
            bool dz = Cfg("deezer", true), au = Cfg("audius", true), ja = Cfg("jamendo", true);
            bool onlyFull = Cfg("onlyfull", false);
            string jkey = Setup.Get("jamkey", "");
            if (jkey.Length == 0) jkey = Extra.JamKey;
            if (!dz && !au && !ja)
            {
                F<TextBlock>("SearchStatus").Text = "Ative uma fonte de música em Ajustes";
                SetItems(F<ListBox>("OnlineRes"), new List<Item>());
                return;
            }
            F<TextBlock>("SearchStatus").Text = "Buscando…";
            ThreadPool.QueueUserWorkItem(delegate
            {
                var res = new List<Item>[3];
                var th = new List<Thread>();
                Action<int, Func<List<Item>>> run = (i, fn) =>
                {
                    var th1 = new Thread(() => { try { res[i] = fn(); } catch (Exception ex) { Util.Log(ex); } });
                    th1.IsBackground = true;
                    th1.Start();
                    th.Add(th1);
                };
                if (ja) run(0, () => Extra.Jamendo(q, jkey));
                if (au) run(1, () => Extra.Audius(q));
                if (dz && !onlyFull) run(2, () => q.Length == 0 ? Web.Chart() : Web.Search(q));
                foreach (var x in th) x.Join(10000);
                var all = new List<Item>();
                foreach (var r in res) if (r != null) all.AddRange(r);
                if (onlyFull) all.RemoveAll(i => !i.Full);
                Ui(() =>
                {
                    if (id != searchId) return;
                    SetItems(F<ListBox>("OnlineRes"), all);
                    F<TextBlock>("SearchStatus").Text = all.Count == 0
                        ? (onlyFull ? "Nenhuma música completa encontrada. Tente Tudo ou outro nome." : (q.Length == 0 ? "Sem internet: mostrando só a sua biblioteca" : "Nada encontrado"))
                        : "";
                });
            });
        }

        // ---------------- letras em tela cheia (disco girando + letras)
        void BuildLyrics()
        {
            F<Button>("BtnLyrics").Click += delegate { ToggleLyrics(); };
            F<Button>("LyricsClose").Click += delegate { ToggleLyrics(); };
            F<Button>("FPrev").Click += delegate { Prev(); };
            F<Button>("FPlay").Click += delegate { Toggle(); };
            F<Button>("FNext").Click += delegate { Next(); };
            lyricTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(60) };
            lyricTimer.Tick += delegate { LyricTick(); };
            SetArc(0);
        }

        void SetArc(double ratio)
        {
            ratio = Math.Max(0, Math.Min(0.9999, ratio));
            double R = 196, cx = 200, cy = 200;
            double ang = ratio * 2 * Math.PI - Math.PI / 2;
            var start = new Point(cx, cy - R);
            var end = new Point(cx + R * Math.Cos(ang), cy + R * Math.Sin(ang));
            var fig = new PathFigure { StartPoint = start, IsClosed = false };
            fig.Segments.Add(new ArcSegment(end, new Size(R, R), 0, ratio > 0.5, SweepDirection.Clockwise, true));
            var geo = new PathGeometry();
            geo.Figures.Add(fig);
            F<System.Windows.Shapes.Path>("ArcPath").Data = geo;
            var kt = F<TranslateTransform>("KnobT");
            kt.X = end.X - 7;
            kt.Y = end.Y - 7;
        }

        void OnPlayState()
        {
            UpdateIsland();
            var fp = F<System.Windows.Shapes.Path>("FPlayIcon");
            if (fp != null) fp.Data = Geometry.Parse(playing ? Geo.Pause : Geo.Play);
            if (perf == 2) return;
            try
            {
                if (spinClock == null)
                {
                    if (!playing) return;
                    var anim = new DoubleAnimation(0, 360, TimeSpan.FromSeconds(14)) { RepeatBehavior = RepeatBehavior.Forever };
                    spinClock = (AnimationClock)anim.CreateClock();
                    F<RotateTransform>("DiscRot").ApplyAnimationClock(RotateTransform.AngleProperty, spinClock);
                }
                else if (playing && spinClock.IsPaused) spinClock.Controller.Resume();
                else if (!playing && !spinClock.IsPaused) spinClock.Controller.Pause();
            }
            catch (Exception ex) { Util.Log(ex); }
        }

        void ToggleLyrics()
        {
            var full = F<Grid>("LyricsFull");
            var disc = F<Grid>("DiscCol");
            var tg = (TransformGroup)disc.RenderTransform;
            var dsc = (ScaleTransform)tg.Children[0];
            var dtt = (TranslateTransform)tg.Children[1];
            var lcol = F<Grid>("LyricsCol");
            var ltt = (TranslateTransform)lcol.RenderTransform;
            var fctl = F<StackPanel>("FCtl");
            var ftt = (TranslateTransform)fctl.RenderTransform;
            var outE = new CubicEase { EasingMode = EasingMode.EaseOut };
            var inE = new CubicEase { EasingMode = EasingMode.EaseIn };
            var spring = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.7 };
            if (!lyricsOpen)
            {
                if (!Cfg("lyrics", true)) { Toast("Ative as letras em Ajustes"); return; }
                lyricsOpen = true;
                foreach (var el in new UIElement[] { disc, lcol, fctl }) { el.BeginAnimation(UIElement.OpacityProperty, null); el.Opacity = 1; }
                dsc.BeginAnimation(ScaleTransform.ScaleXProperty, null); dsc.BeginAnimation(ScaleTransform.ScaleYProperty, null);
                dsc.ScaleX = 1; dsc.ScaleY = 1;
                dtt.BeginAnimation(TranslateTransform.XProperty, null); dtt.X = 0;
                ltt.BeginAnimation(TranslateTransform.XProperty, null); ltt.X = 0;
                ftt.BeginAnimation(TranslateTransform.YProperty, null); ftt.Y = 0;
                full.Effect = null;
                full.Visibility = Visibility.Visible;
                full.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(perf == 2 ? 150 : 420)));
                if (FxFull)
                {
                    var bl = new BlurEffect { Radius = 32 };
                    full.Effect = bl;
                    var ba = new DoubleAnimation(32, 0, TimeSpan.FromMilliseconds(620)) { EasingFunction = outE };
                    ba.Completed += (s, e) => { if (lyricsOpen) full.Effect = null; };
                    bl.BeginAnimation(BlurEffect.RadiusProperty, ba);
                }
                if (perf < 2)
                {
                    var sa = new DoubleAnimation(0.55, 1, TimeSpan.FromMilliseconds(760)) { EasingFunction = spring };
                    dsc.BeginAnimation(ScaleTransform.ScaleXProperty, sa);
                    dsc.BeginAnimation(ScaleTransform.ScaleYProperty, sa);
                    dtt.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(-150, 0, TimeSpan.FromMilliseconds(760)) { EasingFunction = outE });
                    disc.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(480)));
                    ltt.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(150, 0, TimeSpan.FromMilliseconds(760)) { BeginTime = TimeSpan.FromMilliseconds(120), EasingFunction = outE });
                    lcol.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(520)) { BeginTime = TimeSpan.FromMilliseconds(120) });
                    ftt.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(40, 0, TimeSpan.FromMilliseconds(640)) { BeginTime = TimeSpan.FromMilliseconds(300), EasingFunction = spring });
                    fctl.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(420)) { BeginTime = TimeSpan.FromMilliseconds(300) });
                }
                if (curItem != null) { if (lyricsFor != curItem) LoadLyrics(curItem); }
                else { var st = F<TextBlock>("LyricsStatus"); st.Text = "Toque uma música para ver a letra"; st.Visibility = Visibility.Visible; }
                lyricTimer.Start();
                OnPlayState();
                LyricTick();
            }
            else
            {
                lyricsOpen = false;
                lyricTimer.Stop();
                var a = new DoubleAnimation(0, TimeSpan.FromMilliseconds(perf == 2 ? 120 : 360)) { EasingFunction = inE };
                a.Completed += (s, e) => { if (!lyricsOpen) { full.Visibility = Visibility.Collapsed; full.Effect = null; } };
                full.BeginAnimation(UIElement.OpacityProperty, a);
                if (perf < 2)
                {
                    var sa = new DoubleAnimation(1, 0.8, TimeSpan.FromMilliseconds(340)) { EasingFunction = inE };
                    dsc.BeginAnimation(ScaleTransform.ScaleXProperty, sa);
                    dsc.BeginAnimation(ScaleTransform.ScaleYProperty, sa);
                    dtt.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(0, -110, TimeSpan.FromMilliseconds(340)) { EasingFunction = inE });
                    disc.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, TimeSpan.FromMilliseconds(300)));
                    ltt.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(0, 110, TimeSpan.FromMilliseconds(340)) { EasingFunction = inE });
                    lcol.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, TimeSpan.FromMilliseconds(300)));
                    ftt.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0, 30, TimeSpan.FromMilliseconds(300)) { EasingFunction = inE });
                    fctl.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, TimeSpan.FromMilliseconds(240)));
                }
            }
        }

        void LoadLyrics(Item it)
        {
            lyricsFor = it; lrc = null; lrcBlocks = null; lrcIdx = -1;
            F<StackPanel>("LyricsHost").Children.Clear();
            var st = F<TextBlock>("LyricsStatus");
            st.Text = "Buscando letra…";
            st.Visibility = Visibility.Visible;
            string title = it.Name, artist = it.Artist;
            if (string.IsNullOrEmpty(artist) || artist == "Biblioteca")
            {
                artist = null;
                int k = title.IndexOf(" - ");
                if (k > 0) { artist = title.Substring(0, k).Trim(); title = title.Substring(k + 3).Trim(); }
            }
            ThreadPool.QueueUserWorkItem(delegate
            {
                List<LrcLine> synced = null;
                string plain = null;
                try
                {
                    string own = OwnLyrics(it);
                    if (!string.IsNullOrEmpty(own)) Extra.FromText(own, out synced, out plain);
                    else Extra.Lyrics(title, artist, out synced, out plain);
                }
                catch (Exception ex) { Util.Log(ex); }
                Ui(() => { if (lyricsFor == it) ShowLyrics(synced, plain); });
            });
        }

        void ShowLyrics(List<LrcLine> synced, string plain)
        {
            var host = F<StackPanel>("LyricsHost");
            var st = F<TextBlock>("LyricsStatus");
            host.Children.Clear();
            F<ScrollViewer>("LyricsScroll").ScrollToVerticalOffset(0);
            if (synced != null && synced.Count > 0)
            {
                st.Visibility = Visibility.Collapsed;
                lrc = synced;
                lrcBlocks = new List<TextBlock>();
                host.Children.Add(new Border { Height = 150 });
                foreach (var l in synced)
                {
                    var tb = new TextBlock
                    {
                        Text = l.S.Length == 0 ? "♪" : l.S,
                        FontSize = 34,
                        FontWeight = FontWeights.Bold,
                        TextWrapping = TextWrapping.Wrap,
                        Opacity = 0.22,
                        Margin = new Thickness(0, 10, 0, 10),
                        Cursor = Cursors.Hand,
                        Foreground = Brushes.White,
                        RenderTransformOrigin = new Point(0, 0.5),
                        RenderTransform = new ScaleTransform(1, 1)
                    };
                    var line = l;
                    tb.MouseLeftButtonUp += (s, e) => { try { mp.Position = TimeSpan.FromSeconds(line.T); } catch { } };
                    host.Children.Add(tb);
                    lrcBlocks.Add(tb);
                }
                host.Children.Add(new Border { Height = 300 });
            }
            else if (!string.IsNullOrEmpty(plain))
            {
                st.Visibility = Visibility.Collapsed;
                host.Children.Add(new TextBlock { Text = plain, FontSize = 22, FontWeight = FontWeights.SemiBold, LineHeight = 34, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.White, Opacity = 0.92, Margin = new Thickness(0, 30, 0, 80) });
            }
            else
            {
                st.Text = "Letra não encontrada para esta música";
                st.Visibility = Visibility.Visible;
            }
        }

        void LyricTick()
        {
            if (!lyricsOpen || !hasSource) return;
            double pos = mp.Position.TotalSeconds;
            SetArc(dur.TotalSeconds > 0 ? pos / dur.TotalSeconds : 0);
            F<TextBlock>("FTime").Text = Fmt(mp.Position) + " / " + Fmt(dur);
            if (lrc == null || lrcBlocks == null) return;
            double t = pos + 0.25;
            int idx = -1;
            for (int i = 0; i < lrc.Count; i++) { if (lrc[i].T <= t) idx = i; else break; }
            if (idx != lrcIdx)
            {
                int old = lrcIdx;
                lrcIdx = idx;
                int lo = Math.Max(0, Math.Min(old, idx) - 6), hi = Math.Min(lrcBlocks.Count - 1, Math.Max(old, idx) + 6);
                int ms = perf == 2 ? 1 : 380;
                var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
                for (int i = lo; i <= hi; i++)
                {
                    int d = idx < 0 ? 9 : Math.Abs(i - idx);
                    double op = d == 0 ? 1 : d == 1 ? 0.5 : d == 2 ? 0.34 : 0.2;
                    double sc = d == 0 ? 1.06 : 1.0;
                    var tb = lrcBlocks[i];
                    tb.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(op, TimeSpan.FromMilliseconds(ms)) { EasingFunction = ease });
                    var stf = (ScaleTransform)tb.RenderTransform;
                    var sa = new DoubleAnimation(sc, TimeSpan.FromMilliseconds(ms)) { EasingFunction = ease };
                    stf.BeginAnimation(ScaleTransform.ScaleXProperty, sa);
                    stf.BeginAnimation(ScaleTransform.ScaleYProperty, sa);
                }
            }
            if (idx >= 0)
            {
                var sv = F<ScrollViewer>("LyricsScroll");
                var blk = lrcBlocks[idx];
                double y = blk.TranslatePoint(new Point(0, 0), F<StackPanel>("LyricsHost")).Y;
                double target = Math.Max(0, y - sv.ViewportHeight / 2 + blk.ActualHeight / 2);
                sv.ScrollToVerticalOffset(sv.VerticalOffset + (target - sv.VerticalOffset) * 0.16);
            }
        }

        // ---------------- ilha dinâmica
        void BuildIsland()
        {
            island = new IslandWin();
            try { island.Create(); }
            catch (Exception ex) { Util.Log(ex); island = null; return; }
            island.OnPrev = Prev;
            island.OnNext = Next;
            island.OnToggle = Toggle;
            island.OnOpen = () => { if (W.WindowState == WindowState.Minimized) W.WindowState = WindowState.Normal; W.Activate(); };
            W.Closed += delegate { island.Close(); };
            islandTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            islandTimer.Tick += delegate { UpdateIsland(); };
            islandTimer.Start();
        }

        void UpdateIsland()
        {
            if (island == null) return;
            if (playing) lastPlay = DateTime.Now;
            island.SetShown(islandOn && (playing || island.NotifyActive || (DateTime.Now - lastPlay).TotalSeconds < 8));
            island.SetPlaying(playing);
        }

        void Notify(string text)
        {
            if (island != null && islandOn) island.Notify(text);
        }

        // ---------------- ajustes (módulos, integrações e desempenho)
        StackPanel Card(StackPanel host, string title)
        {
            var sp = new StackPanel();
            sp.Children.Add(new TextBlock { Text = title, FontSize = 17, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 6) });
            var b = new Border
            {
                CornerRadius = new CornerRadius(26),
                Background = new SolidColorBrush(Color.FromArgb(0x14, 255, 255, 255)),
                BorderBrush = (Brush)W.FindResource("GlassBrd"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(22, 16, 22, 16),
                Margin = new Thickness(0, 0, 12, 14),
                Child = sp
            };
            host.Children.Add(b);
            return sp;
        }

        CheckBox Row(StackPanel card, string title, string desc, string key, bool def, Action<bool> on)
        {
            var g = new Grid { Margin = new Thickness(0, 6, 0, 6) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var t = new StackPanel { Margin = new Thickness(0, 0, 16, 0) };
            t.Children.Add(new TextBlock { Text = title, FontSize = 14.5, FontWeight = FontWeights.SemiBold });
            t.Children.Add(new TextBlock { Text = desc, FontSize = 12, TextWrapping = TextWrapping.Wrap, Foreground = new SolidColorBrush(Color.FromArgb(0x88, 255, 255, 255)) });
            g.Children.Add(t);
            var cb = new CheckBox { Style = (Style)W.FindResource("Sw"), IsChecked = Cfg(key, def), VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(cb, 1);
            g.Children.Add(cb);
            cb.Click += delegate { bool v = cb.IsChecked == true; SetCfg(key, v); if (on != null) on(v); };
            card.Children.Add(g);
            return cb;
        }

        void BuildSettings()
        {
            var host = F<StackPanel>("SettingsHost");

            var s1 = Card(host, "Fontes de música (módulos)");
            Row(s1, "Deezer", "Milhões de faixas, mas só a prévia de 30 segundos (limite deles).", "deezer", true, null);
            Row(s1, "Audius", "Músicas COMPLETAS de artistas independentes, grátis.", "audius", true, null);
            Row(s1, "Jamendo", "Músicas COMPLETAS livres. Já configurado com a chave do app capimm-rust.", "jamendo", true, null);
            var key = new TextBox { Text = Setup.Get("jamkey", "").Length > 0 ? Setup.Get("jamkey", "") : Extra.JamKey, FontSize = 13, Padding = new Thickness(16, 8, 16, 8), Margin = new Thickness(0, 6, 0, 2), ToolTip = "Cole aqui a sua chave (client_id) do Jamendo" };
            key.TextChanged += delegate { Setup.Set("jamkey", key.Text.Trim()); };
            s1.Children.Add(key);
            s1.Children.Add(new TextBlock { Text = "Suas músicas importadas (arquivos mp3, flac...) sempre tocam inteiras.", FontSize = 12, Margin = new Thickness(2, 6, 0, 0), Foreground = new SolidColorBrush(Color.FromArgb(0x77, 255, 255, 255)) });

            var s2 = Card(host, "Letras");
            Row(s2, "Letras sincronizadas", "Mostra a letra rolando junto com a música (LRCLIB). Atalho: tecla L.", "lyrics", true, v => { if (!v && lyricsOpen) ToggleLyrics(); });

            var s3 = Card(host, "Aparência");
            Row(s3, "Fundo dinâmico", "O fundo e o modo letras ganham as cores da capa da música.", "bgdyn", true, v => { ApplyPalette(lastPal); });
            Row(s3, "Ilha dinâmica", "Pílula flutuante no topo da tela com a música e avisos de mensagens e ligações.", "island", true, v => { islandOn = v; UpdateIsland(); });

            var s4 = Card(host, "Desempenho");
            s4.Children.Add(new TextBlock { Text = "Máximo: todas as animações e blur. Equilibrado: sem blur nas trocas. Economia: sem efeitos, menos uso de CPU e bateria (reinicie o app para limitar a 30 FPS).", FontSize = 12, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10), Foreground = new SolidColorBrush(Color.FromArgb(0x88, 255, 255, 255)) });
            var seg = new Border { CornerRadius = new CornerRadius(21), Background = new SolidColorBrush(Color.FromArgb(0x1A, 255, 255, 255)), BorderBrush = new SolidColorBrush(Color.FromArgb(0x26, 255, 255, 255)), BorderThickness = new Thickness(1), HorizontalAlignment = HorizontalAlignment.Left, Padding = new Thickness(3) };
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            string[] names = { "Máximo visual", "Equilibrado", "Economia" };
            for (int i = 0; i < 3; i++)
            {
                int k = i;
                var rb = new RadioButton { Style = (Style)W.FindResource("Seg"), Content = names[i], GroupName = "perf", IsChecked = perf == i };
                rb.Checked += (s, e) => { perf = k; Setup.Set("perf", k.ToString()); ApplyPerf(); };
                sp.Children.Add(rb);
            }
            seg.Child = sp;
            s4.Children.Add(seg);

            var s5 = Card(host, "Rede e privacidade");
            Row(s5, "Compartilhar minha biblioteca", "Amigos e a rede CM-R podem ver e baixar as músicas que você publicar (e as da sua pasta).", "Share", true, v => { server.Share = v; });
            Row(s5, "Não perturbe", "Bloqueia mensagens e ligações de outras pessoas.", "Dnd", false, v => { server.Dnd = v; });
            Row(s5, "Notificações", "Avisa na ilha dinâmica quando chegar mensagem ou ligação.", "notif", true, null);

            var s6 = Card(host, "Sistema");
            Row(s6, "Iniciar com o Windows", "Abre o capimm-rust sozinho quando você liga o PC.", "startup", false, v => { SetStartup(v); });
            var br = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 10, 0, 0) };
            var b1 = new Button { Style = (Style)W.FindResource("Btn"), Content = "Abrir pasta da biblioteca", Margin = new Thickness(0, 0, 10, 0) };
            b1.Click += delegate { try { Process.Start("explorer.exe", "\"" + Util.LibDir + "\""); } catch (Exception ex) { Util.Log(ex); } };
            var b2 = new Button { Style = (Style)W.FindResource("Btn"), Content = "Limpar cache de músicas" };
            b2.Click += delegate { ClearCache(); };
            br.Children.Add(b1); br.Children.Add(b2);
            s6.Children.Add(br);
            s6.Children.Add(new TextBlock { Text = "capimm-rust 4.0  ·  atalhos: Espaço pausa, setas avançam 10 s, L abre a letra", FontSize = 12, Margin = new Thickness(2, 12, 0, 0), Foreground = new SolidColorBrush(Color.FromArgb(0x66, 255, 255, 255)) });
        }

        void SetStartup(bool on)
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (k == null) return;
                    if (on) k.SetValue("capimm-rust", "\"" + Process.GetCurrentProcess().MainModule.FileName + "\"");
                    else k.DeleteValue("capimm-rust", false);
                }
            }
            catch (Exception ex) { Util.Log(ex); }
        }

        void ClearCache()
        {
            long bytes = 0;
            try
            {
                string dir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "capimm-rust");
                if (Directory.Exists(dir))
                    foreach (var f in Directory.GetFiles(dir))
                    {
                        try { bytes += new FileInfo(f).Length; File.Delete(f); } catch { }
                    }
            }
            catch (Exception ex) { Util.Log(ex); }
            Toast("Cache limpo (" + (bytes / 1048576) + " MB)");
        }

        void ApplyPerf()
        {
            F<Canvas>("GlowCanvas").Visibility = perf < 2 ? Visibility.Visible : Visibility.Collapsed;
            var g1 = F<TranslateTransform>("G1");
            var g2 = F<TranslateTransform>("G2");
            var g3 = F<TranslateTransform>("G3");
            if (perf == 0)
            {
                Drift(g1, 170, 120, 15, 11);
                Drift(g2, -190, -130, 13, 17);
                Drift(g3, 150, -90, 17, 12);
            }
            else
            {
                foreach (var g in new[] { g1, g2, g3 })
                {
                    g.BeginAnimation(TranslateTransform.XProperty, null);
                    g.BeginAnimation(TranslateTransform.YProperty, null);
                }
            }
            if (eqTimer != null)
            {
                eqTimer.Interval = TimeSpan.FromMilliseconds(perf == 0 ? 90 : 160);
                if (perf == 2) eqTimer.Stop(); else eqTimer.Start();
            }
            ApplyPalette(lastPal);
        }
    }
}
