using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace Pulse
{
    public class Item
    {
        public string Name { get; set; }
        public string Artist { get; set; }
        public string Path { get; set; }
        public string Url { get; set; }
        public string Cover { get; set; }
        public string CoverBig { get; set; }
        public string Tag { get; set; }
        public string Source { get; set; }
        public bool Full { get; set; }
        public string Addr { get; set; }
        public string PubId { get; set; }
        public string Owner { get; set; }
        public string Ext { get; set; }
        public List<string> Alts { get; set; }
    }

    public class Source
    {
        public string Label { get; set; }
        public string Path { get; set; }
        public string CountText { get; set; }
    }

    public static class Util
    {
        static readonly string[] Ext = { ".mp3", ".flac", ".wav", ".ogg", ".m4a", ".aac", ".wma" };

        public static bool IsAudio(string p)
        {
            return Array.IndexOf(Ext, System.IO.Path.GetExtension(p).ToLowerInvariant()) >= 0;
        }

        public static bool IsPlaylist(string p)
        {
            string e = System.IO.Path.GetExtension(p).ToLowerInvariant();
            return e == ".m3u" || e == ".m3u8" || e == ".pls";
        }

        public static string LibDir
        {
            get
            {
                string d = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyMusic), "capimm-rust");
                Directory.CreateDirectory(d);
                return d;
            }
        }

        public static string SafeName(string n)
        {
            if (string.IsNullOrEmpty(n)) return null;
            string f = System.IO.Path.GetFileName(n);
            if (f != n || n.Contains("..") || !IsAudio(f)) return null;
            return f;
        }

        public static void Log(Exception ex)
        {
            try
            {
                string d = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "capimm-rust");
                Directory.CreateDirectory(d);
                File.AppendAllText(System.IO.Path.Combine(d, "erro.txt"), DateTime.Now + "\r\n" + ex + "\r\n\r\n");
            }
            catch { }
        }

        public static string Clean(string s)
        {
            return (s ?? "").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
        }

        public static List<Item> Tracks(string dir)
        {
            var r = new List<Item>();
            try
            {
                foreach (string f in Directory.GetFiles(dir))
                    if (IsAudio(f))
                    {
                        string n = System.IO.Path.GetFileNameWithoutExtension(f);
                        r.Add(new Item { Name = n, Artist = "Biblioteca", Path = f, Tag = "local", Full = true });
                    }
            }
            catch { }
            r.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.CurrentCultureIgnoreCase));
            return r;
        }

        public static void Collect(string dir, List<string> acc, int cap, int depth, string skip)
        {
            if (acc.Count >= cap || depth > 8) return;
            if (skip != null && string.Equals(dir.TrimEnd('\\'), skip.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)) return;
            try
            {
                foreach (string f in Directory.GetFiles(dir))
                {
                    if (IsAudio(f)) { acc.Add(f); if (acc.Count >= cap) return; }
                }
            }
            catch { }
            try
            {
                foreach (string d in Directory.GetDirectories(dir))
                {
                    Collect(d, acc, cap, depth + 1, skip);
                    if (acc.Count >= cap) return;
                }
            }
            catch { }
        }

        public static List<string> ReadPlaylist(string file)
        {
            var r = new List<string>();
            string baseDir = System.IO.Path.GetDirectoryName(file);
            foreach (string raw in File.ReadAllLines(file))
            {
                string l = raw.Trim();
                if (l.Length == 0 || l.StartsWith("#")) continue;
                if (l.StartsWith("File", StringComparison.OrdinalIgnoreCase) && l.Contains("="))
                    l = l.Substring(l.IndexOf('=') + 1).Trim();
                else if (l.Contains("=") && !l.Contains("\\") && !l.Contains("/")) continue;
                if (l.StartsWith("file:///")) l = Uri.UnescapeDataString(l.Substring(8)).Replace('/', '\\');
                if (l.StartsWith("http", StringComparison.OrdinalIgnoreCase)) continue;
                try
                {
                    string full = System.IO.Path.IsPathRooted(l) ? l : System.IO.Path.Combine(baseDir, l);
                    if (File.Exists(full) && IsAudio(full)) r.Add(full);
                }
                catch { }
            }
            return r;
        }

        // código de convite: IP + porta em 12 dígitos hexadecimais (ex.: C0A8-010A-1EC6)
        public static string MakeCode(string ip, int port)
        {
            IPAddress a;
            if (!IPAddress.TryParse(ip, out a)) return "----";
            byte[] b = a.GetAddressBytes();
            if (b.Length != 4) return "----";
            string h = b[0].ToString("X2") + b[1].ToString("X2") + b[2].ToString("X2") + b[3].ToString("X2") + ((port >> 8) & 255).ToString("X2") + (port & 255).ToString("X2");
            return h.Substring(0, 4) + "-" + h.Substring(4, 4) + "-" + h.Substring(8, 4);
        }

        // aceita código, "ip:porta" ou só "ip"; devolve "ip:porta" ou null
        public static string ParseCode(string s)
        {
            if (s == null) return null;
            s = s.Trim();
            string h = s.Replace("-", "").Replace(" ", "");
            if (h.Length == 12)
            {
                try
                {
                    int p0 = Convert.ToInt32(h.Substring(0, 2), 16), p1 = Convert.ToInt32(h.Substring(2, 2), 16);
                    int p2 = Convert.ToInt32(h.Substring(4, 2), 16), p3 = Convert.ToInt32(h.Substring(6, 2), 16);
                    int port = Convert.ToInt32(h.Substring(8, 4), 16);
                    return p0 + "." + p1 + "." + p2 + "." + p3 + ":" + port;
                }
                catch { }
            }
            string host = s; int pp = 7878;
            int i = s.LastIndexOf(':');
            if (i > 0) { int.TryParse(s.Substring(i + 1), out pp); host = s.Substring(0, i); }
            IPAddress ip;
            if (IPAddress.TryParse(host, out ip)) return ip + ":" + pp;
            return null;
        }
    }

    public static class Wire
    {
        public static string ReadLine(Stream s)
        {
            var ms = new MemoryStream();
            int b;
            while ((b = s.ReadByte()) >= 0)
            {
                if (b == '\n') break;
                if (b != '\r') ms.WriteByte((byte)b);
                if (ms.Length > 16384) throw new IOException("linha muito grande");
            }
            if (b < 0 && ms.Length == 0) return null;
            return Encoding.UTF8.GetString(ms.ToArray());
        }

        public static void Send(Stream s, string line)
        {
            byte[] d = Encoding.UTF8.GetBytes(line + "\n");
            s.Write(d, 0, d.Length);
        }
    }

    // ---------------------------------------------------------------- busca online (Deezer: prévias de 30 s)
    public static class Web
    {
        static string Get(string url)
        {
            var r = (HttpWebRequest)WebRequest.Create(url);
            r.UserAgent = "capimm-rust/3.0";
            r.Timeout = 8000;
            using (var resp = r.GetResponse())
            using (var s = resp.GetResponseStream())
            using (var sr = new StreamReader(s, Encoding.UTF8))
                return sr.ReadToEnd();
        }

        static string S(Dictionary<string, object> d, string k)
        {
            object v;
            if (d != null && d.TryGetValue(k, out v) && v != null) return v.ToString();
            return "";
        }

        static Dictionary<string, object> D(Dictionary<string, object> d, string k)
        {
            object v;
            if (d != null && d.TryGetValue(k, out v)) return v as Dictionary<string, object>;
            return null;
        }

        static List<Item> Parse(string json)
        {
            var res = new List<Item>();
            var js = new JavaScriptSerializer();
            js.MaxJsonLength = int.MaxValue;
            var root = js.DeserializeObject(json) as Dictionary<string, object>;
            object dv;
            if (root == null || !root.TryGetValue("data", out dv)) return res;
            var arr = dv as System.Collections.IEnumerable;
            if (arr == null) return res;
            foreach (object o in arr)
            {
                var d = o as Dictionary<string, object>;
                if (d == null) continue;
                string prev = S(d, "preview");
                if (prev.Length == 0) continue;
                string cover = S(D(d, "album"), "cover_medium");
                string big = S(D(d, "album"), "cover_big");
                res.Add(new Item { Name = S(d, "title"), Artist = S(D(d, "artist"), "name"), Cover = cover.Length == 0 ? null : cover, CoverBig = big.Length == 0 ? null : big, Url = prev, Tag = "prévia 30 s", Source = "Deezer" });
            }
            return res;
        }

        public static List<Item> Search(string q) { return Parse(Get("https://api.deezer.com/search?limit=30&q=" + Uri.EscapeDataString(q))); }
        public static List<Item> Chart() { return Parse(Get("https://api.deezer.com/chart/0/tracks?limit=30")); }
    }

    // ---------------------------------------------------------------- servidor embutido (o PC de quem usa é o servidor)
    public class Server
    {
        public string Dir;
        public volatile bool Share = true;
        public volatile bool Dnd = false;
        public Func<string> MyNick;
        public Func<List<string>> Peers;
        public Action<string, int, string, string> OnDM;   // ip, porta, apelido, texto
        public Action<string, int, CallSession> OnCall;     // ip, porta, ligação
        TcpListener listener;

        public void Start(int port)
        {
            listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            var t = new Thread(Loop);
            t.IsBackground = true;
            t.Start();
        }

        void Loop()
        {
            while (true)
            {
                TcpClient c;
                try { c = listener.AcceptTcpClient(); }
                catch { return; }
                var cc = c;
                var t = new Thread(() => Handle(cc));
                t.IsBackground = true;
                t.Start();
            }
        }

        void Handle(TcpClient c)
        {
            try
            {
                using (c)
                {
                    var ns = c.GetStream();
                    var rd = new BufferedStream(ns, 8192);
                    string line = Wire.ReadLine(rd);
                    if (line == null) return;
                    string[] p = line.Split(new char[] { '\t' }, 4);
                    string ip = ((IPEndPoint)c.Client.RemoteEndPoint).Address.ToString();
                    int port = 7878;
                    if (p.Length > 2) { int pp; if (int.TryParse(p[2], out pp)) port = pp; }

                    if (p[0] == "HI")
                    {
                        Wire.Send(ns, "OK\t" + Util.Clean(MyNick != null ? MyNick() : "capimm-rust"));
                    }
                    else if (p[0] == "LIST")
                    {
                        if (!Share) { Wire.Send(ns, "ERR\tprivado"); return; }
                        var t = Util.Tracks(Dir);
                        Wire.Send(ns, "OK\t" + t.Count);
                        foreach (var i in t)
                            Wire.Send(ns, System.IO.Path.GetFileName(i.Path));
                    }
                    else if (p[0] == "GET" && p.Length > 1)
                    {
                        if (!Share) { Wire.Send(ns, "ERR\tprivado"); return; }
                        string name = Util.SafeName(p[1]);
                        if (name == null) { Wire.Send(ns, "ERR\tnome"); return; }
                        string path = System.IO.Path.Combine(Dir, name);
                        if (!File.Exists(path)) { Wire.Send(ns, "ERR\tnao existe"); return; }
                        using (var fs = File.OpenRead(path))
                        {
                            Wire.Send(ns, "OK\t" + fs.Length);
                            var buf = new byte[65536];
                            int n;
                            while ((n = fs.Read(buf, 0, buf.Length)) > 0) ns.Write(buf, 0, n);
                        }
                    }
                    else if (p[0] == "CAT")
                    {
                        if (!Share) { Wire.Send(ns, "ERR\tprivado"); return; }
                        var pubs = Store.PubsSnapshot();
                        Wire.Send(ns, "OK\t" + pubs.Count);
                        var js = new JavaScriptSerializer();
                        string owner = Util.Clean(MyNick != null ? MyNick() : "");
                        foreach (var pb in pubs)
                            Wire.Send(ns, js.Serialize(new { id = pb.Id, title = Util.Clean(pb.Title), artist = Util.Clean(pb.Artist), owner = owner, ext = System.IO.Path.GetExtension(pb.File ?? ""), size = pb.Size }));
                    }
                    else if (p[0] == "PGET" && p.Length > 1)
                    {
                        if (!Share) { Wire.Send(ns, "ERR\tprivado"); return; }
                        var pb = Store.FindPub(p[1]);
                        string fn = pb == null ? null : Util.SafeName(pb.File);
                        string fpath = fn == null ? null : System.IO.Path.Combine(Dir, fn);
                        if (fpath == null || !File.Exists(fpath)) { Wire.Send(ns, "ERR\tnao existe"); return; }
                        using (var fs = File.OpenRead(fpath))
                        {
                            Wire.Send(ns, "OK\t" + fs.Length);
                            var buf = new byte[65536];
                            int nn;
                            while ((nn = fs.Read(buf, 0, buf.Length)) > 0) ns.Write(buf, 0, nn);
                        }
                    }
                    else if (p[0] == "PLYR" && p.Length > 1)
                    {
                        if (!Share) { Wire.Send(ns, "ERR\tprivado"); return; }
                        var pb = Store.FindPub(p[1]);
                        byte[] lb = Encoding.UTF8.GetBytes(pb == null ? "" : (pb.Lyrics ?? ""));
                        Wire.Send(ns, "OK\t" + lb.Length);
                        ns.Write(lb, 0, lb.Length);
                    }
                    else if (p[0] == "PEERS")
                    {
                        var pl = Peers != null ? Peers() : new List<string>();
                        Wire.Send(ns, "OK\t" + pl.Count);
                        foreach (var a in pl) Wire.Send(ns, a);
                    }
                    else if (p[0] == "SUB" && p.Length > 2)
                    {
                        bool isOwner = IPAddress.IsLoopback(((IPEndPoint)c.Client.RemoteEndPoint).Address);
                        GuildHost.Serve(ns, rd, p[1], Util.Clean(p[2]), isOwner);
                    }
                    else if (p[0] == "DM" && p.Length > 3)
                    {
                        if (Dnd) { Wire.Send(ns, "ERR\tnaoperturbe"); return; }
                        if (OnDM != null) OnDM(ip, port, Util.Clean(p[1]), Util.Clean(p[3]));
                        Wire.Send(ns, "OK");
                    }
                    else if (p[0] == "CALL" && p.Length > 2)
                    {
                        if (Dnd) { Wire.Send(ns, "DECLINE"); return; }
                        var s = new CallSession(c, ns, rd);
                        s.PeerName = Util.Clean(p[1]);
                        if (OnCall != null) OnCall(ip, port, s);
                        s.RunCallee();
                    }
                }
            }
            catch { }
        }
    }

    public static class Client
    {
        public static TcpClient Open(string addr)
        {
            string host = addr.Trim();
            int port = 7878;
            int i = host.LastIndexOf(':');
            if (i > 0)
            {
                int pp;
                if (int.TryParse(host.Substring(i + 1), out pp)) port = pp;
                host = host.Substring(0, i);
            }
            var c = new TcpClient();
            var ar = c.BeginConnect(host, port, null, null);
            if (!ar.AsyncWaitHandle.WaitOne(4000))
            {
                c.Close();
                throw new Exception("não consegui conectar (offline?)");
            }
            c.EndConnect(ar);
            c.NoDelay = true;
            return c;
        }

        public static string Hello(string addr)
        {
            using (var c = Open(addr))
            {
                c.ReceiveTimeout = 5000;
                var ns = c.GetStream();
                var rd = new BufferedStream(ns, 1024);
                Wire.Send(ns, "HI");
                string h = Wire.ReadLine(rd);
                if (h == null || !h.StartsWith("OK\t")) throw new Exception("resposta inválida");
                return h.Substring(3);
            }
        }

        public static void SendDM(string addr, string nick, int myPort, string text)
        {
            using (var c = Open(addr))
            {
                c.ReceiveTimeout = 5000;
                var ns = c.GetStream();
                var rd = new BufferedStream(ns, 1024);
                Wire.Send(ns, "DM\t" + Util.Clean(nick) + "\t" + myPort + "\t" + Util.Clean(text));
                string h = Wire.ReadLine(rd);
                if (h == null || !h.StartsWith("OK"))
                    throw new Exception(h != null && h.Contains("naoperturbe") ? "não perturbe ligado" : "não entregue");
            }
        }

        public static List<Item> List(string addr)
        {
            using (var c = Open(addr))
            {
                c.ReceiveTimeout = 15000;
                var ns = c.GetStream();
                var rd = new BufferedStream(ns, 8192);
                Wire.Send(ns, "LIST");
                string h = Wire.ReadLine(rd);
                if (h == null || !h.StartsWith("OK")) throw new Exception(h != null && h.Contains("privado") ? "biblioteca privada" : "resposta inválida");
                int n = int.Parse(h.Split('\t')[1]);
                var r = new List<Item>();
                for (int k = 0; k < n; k++)
                {
                    string l = Wire.ReadLine(rd);
                    if (l == null) break;
                    r.Add(new Item { Name = System.IO.Path.GetFileNameWithoutExtension(l), Artist = l, Path = l });
                }
                return r;
            }
        }

        public static void Download(string addr, string name, string dest)
        {
            using (var c = Open(addr))
            {
                c.ReceiveTimeout = 20000;
                var ns = c.GetStream();
                var rd = new BufferedStream(ns, 65536);
                Wire.Send(ns, "GET\t" + name);
                string h = Wire.ReadLine(rd);
                if (h == null || !h.StartsWith("OK")) throw new Exception("arquivo indisponível");
                long size = long.Parse(h.Split('\t')[1]);
                string tmp = dest + ".part";
                using (var fs = File.Create(tmp))
                {
                    var buf = new byte[65536];
                    long got = 0;
                    while (got < size)
                    {
                        int n = rd.Read(buf, 0, (int)Math.Min(buf.Length, size - got));
                        if (n <= 0) throw new IOException("conexão caiu");
                        fs.Write(buf, 0, n);
                        got += n;
                    }
                }
                if (File.Exists(dest)) File.Delete(dest);
                File.Move(tmp, dest);
            }
        }
    }

    // ---------------------------------------------------------------- descoberta automática na rede local
    public class Discovery
    {
        public Action<string, string, int> OnPeer; // ip, apelido, porta
        public Func<string> Nick;
        const int UdpPort = 7879;

        public void Start(int tcpPort)
        {
            var local = new HashSet<string>();
            try { foreach (var a in Dns.GetHostEntry(Dns.GetHostName()).AddressList) local.Add(a.ToString()); } catch { }
            local.Add("127.0.0.1");
            try
            {
                var rx = new UdpClient();
                rx.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                rx.Client.Bind(new IPEndPoint(IPAddress.Any, UdpPort));
                var t = new Thread(() =>
                {
                    while (true)
                    {
                        try
                        {
                            var ep = new IPEndPoint(IPAddress.Any, 0);
                            byte[] d = rx.Receive(ref ep);
                            string[] p = Encoding.UTF8.GetString(d).Split('\t');
                            int port;
                            if (p.Length < 3 || p[0] != "PULSE1" || !int.TryParse(p[2], out port)) continue;
                            string ip = ep.Address.ToString();
                            if (local.Contains(ip) && port == tcpPort) continue;
                            if (OnPeer != null) OnPeer(ip, p[1], port);
                        }
                        catch { Thread.Sleep(500); }
                    }
                });
                t.IsBackground = true;
                t.Start();
            }
            catch { }
            var s = new Thread(() =>
            {
                UdpClient tx = null;
                try { tx = new UdpClient(); tx.EnableBroadcast = true; } catch { return; }
                while (true)
                {
                    try
                    {
                        byte[] b = Encoding.UTF8.GetBytes("PULSE1\t" + Util.Clean(Nick != null ? Nick() : "capimm-rust") + "\t" + tcpPort);
                        tx.Send(b, b.Length, new IPEndPoint(IPAddress.Broadcast, UdpPort));
                    }
                    catch { }
                    Thread.Sleep(3000);
                }
            });
            s.IsBackground = true;
            s.Start();
        }
    }

    // ---------------------------------------------------------------- ligação de voz
    public class CallSession
    {
        public string PeerName;
        public Action<byte[]> OnAudio;
        public Action OnAccepted, OnDeclined, OnEnded;
        readonly TcpClient tcp;
        readonly Stream ns;
        readonly BufferedStream rd;
        readonly object wl = new object();
        readonly ManualResetEvent decided = new ManualResetEvent(false);
        volatile bool ended;
        volatile int decision;

        public CallSession(TcpClient c, Stream s, BufferedStream r) { tcp = c; ns = s; rd = r; }

        public static CallSession Dial(string addr, string nick, int port)
        {
            var c = Client.Open(addr);
            var ns = c.GetStream();
            Wire.Send(ns, "CALL\t" + Util.Clean(nick) + "\t" + port);
            return new CallSession(c, ns, new BufferedStream(ns, 8192));
        }

        // lado de quem liga
        public void RunCaller()
        {
            try
            {
                tcp.ReceiveTimeout = 50000;
                while (true)
                {
                    string l = Wire.ReadLine(rd);
                    if (l == null) break;
                    if (l == "ACCEPT")
                    {
                        tcp.ReceiveTimeout = 0;
                        if (OnAccepted != null) OnAccepted();
                        AudioLoop();
                        return;
                    }
                    if (l == "DECLINE") { if (OnDeclined != null) OnDeclined(); break; }
                }
            }
            catch { }
            End();
        }

        // lado de quem recebe (roda na thread do servidor)
        public void RunCallee()
        {
            try
            {
                Wire.Send(ns, "RING");
                if (!decided.WaitOne(45000) || decision != 1) { End(); return; }
                AudioLoop();
            }
            catch { End(); }
        }

        public void Accept()
        {
            try { lock (wl) Wire.Send(ns, "ACCEPT"); } catch { }
            decision = 1;
            decided.Set();
        }

        public void Decline()
        {
            try { lock (wl) Wire.Send(ns, "DECLINE"); } catch { }
            decision = 2;
            decided.Set();
        }

        void ReadExact(byte[] b, int n)
        {
            int got = 0;
            while (got < n)
            {
                int r = rd.Read(b, got, n - got);
                if (r <= 0) throw new IOException("fim");
                got += r;
            }
        }

        void AudioLoop()
        {
            try
            {
                var hdr = new byte[2];
                while (!ended)
                {
                    ReadExact(hdr, 2);
                    int n = hdr[0] | (hdr[1] << 8);
                    if (n <= 0 || n > 4096) break;
                    var b = new byte[n];
                    ReadExact(b, n);
                    if (OnAudio != null) OnAudio(b);
                }
            }
            catch { }
            End();
        }

        public void SendAudio(byte[] b)
        {
            if (ended) return;
            try
            {
                lock (wl)
                {
                    var f = new byte[2 + b.Length];
                    f[0] = (byte)(b.Length & 255);
                    f[1] = (byte)(b.Length >> 8);
                    Buffer.BlockCopy(b, 0, f, 2, b.Length);
                    ns.Write(f, 0, f.Length);
                }
            }
            catch { End(); }
        }

        public void End()
        {
            if (ended) return;
            ended = true;
            decided.Set();
            try { tcp.Close(); } catch { }
            if (OnEnded != null) OnEnded();
        }
    }

    // microfone e alto-falante via winmm (PCM 16 kHz, 16 bits, mono)
    public class Voice
    {
        public const int Buf = 640; // 20 ms
        const int N = 8;
        [StructLayout(LayoutKind.Sequential)]
        struct WAVEFORMATEX { public ushort wFormatTag, nChannels; public uint nSamplesPerSec, nAvgBytesPerSec; public ushort nBlockAlign, wBitsPerSample, cbSize; }
        [StructLayout(LayoutKind.Sequential)]
        struct WAVEHDR { public IntPtr lpData; public uint dwBufferLength, dwBytesRecorded; public IntPtr dwUser; public uint dwFlags, dwLoops; public IntPtr lpNext, reserved; }

        [DllImport("winmm.dll")] static extern int waveInOpen(out IntPtr h, uint dev, ref WAVEFORMATEX f, IntPtr cb, IntPtr inst, uint flags);
        [DllImport("winmm.dll")] static extern int waveInPrepareHeader(IntPtr h, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern int waveInUnprepareHeader(IntPtr h, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern int waveInAddBuffer(IntPtr h, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern int waveInStart(IntPtr h);
        [DllImport("winmm.dll")] static extern int waveInReset(IntPtr h);
        [DllImport("winmm.dll")] static extern int waveInClose(IntPtr h);
        [DllImport("winmm.dll")] static extern int waveOutOpen(out IntPtr h, uint dev, ref WAVEFORMATEX f, IntPtr cb, IntPtr inst, uint flags);
        [DllImport("winmm.dll")] static extern int waveOutPrepareHeader(IntPtr h, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern int waveOutUnprepareHeader(IntPtr h, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern int waveOutWrite(IntPtr h, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern int waveOutReset(IntPtr h);
        [DllImport("winmm.dll")] static extern int waveOutClose(IntPtr h);

        static readonly int HS = Marshal.SizeOf(typeof(WAVEHDR));
        IntPtr hin = IntPtr.Zero, hout = IntPtr.Zero;
        readonly IntPtr[] inH = new IntPtr[N], outH = new IntPtr[N];
        readonly AutoResetEvent ev = new AutoResetEvent(false);
        readonly object po = new object();
        Thread cap;
        volatile bool run;
        int wi;
        public Action<byte[]> OnCapture;

        static IntPtr NewHdr(int len)
        {
            var h = new WAVEHDR();
            h.lpData = Marshal.AllocHGlobal(len);
            h.dwBufferLength = (uint)len;
            IntPtr p = Marshal.AllocHGlobal(HS);
            Marshal.StructureToPtr(h, p, false);
            return p;
        }

        public bool Start()
        {
            var f = new WAVEFORMATEX();
            f.wFormatTag = 1; f.nChannels = 1; f.nSamplesPerSec = 16000; f.nAvgBytesPerSec = 32000; f.nBlockAlign = 2; f.wBitsPerSample = 16; f.cbSize = 0;
            uint mapper = 0xFFFFFFFF;
            bool mic = false;
            try
            {
                if (waveOutOpen(out hout, mapper, ref f, IntPtr.Zero, IntPtr.Zero, 0) == 0)
                {
                    for (int i = 0; i < N; i++) { outH[i] = NewHdr(Buf); waveOutPrepareHeader(hout, outH[i], HS); }
                }
                else hout = IntPtr.Zero;
                if (waveInOpen(out hin, mapper, ref f, ev.SafeWaitHandle.DangerousGetHandle(), IntPtr.Zero, 0x50000) == 0)
                {
                    for (int i = 0; i < N; i++)
                    {
                        inH[i] = NewHdr(Buf);
                        waveInPrepareHeader(hin, inH[i], HS);
                        waveInAddBuffer(hin, inH[i], HS);
                    }
                    run = true;
                    cap = new Thread(CapLoop);
                    cap.IsBackground = true;
                    cap.Start();
                    waveInStart(hin);
                    mic = true;
                }
                else hin = IntPtr.Zero;
            }
            catch { }
            return mic;
        }

        void CapLoop()
        {
            int next = 0;
            while (run)
            {
                ev.WaitOne(200);
                while (run)
                {
                    var h = (WAVEHDR)Marshal.PtrToStructure(inH[next], typeof(WAVEHDR));
                    if ((h.dwFlags & 1) == 0) break;
                    var b = new byte[h.dwBytesRecorded];
                    if (b.Length > 0) Marshal.Copy(h.lpData, b, 0, b.Length);
                    waveInAddBuffer(hin, inH[next], HS);
                    next = (next + 1) % N;
                    if (b.Length > 0 && OnCapture != null) OnCapture(b);
                }
            }
        }

        public void Play(byte[] pcm)
        {
            if (hout == IntPtr.Zero || pcm.Length > Buf) return;
            lock (po)
            {
                if (hout == IntPtr.Zero) return;
                var h = (WAVEHDR)Marshal.PtrToStructure(outH[wi], typeof(WAVEHDR));
                if ((h.dwFlags & 0x10) != 0) return; // ainda tocando: descarta para não acumular atraso
                Marshal.Copy(pcm, 0, h.lpData, pcm.Length);
                Marshal.WriteInt32(outH[wi], (int)Marshal.OffsetOf(typeof(WAVEHDR), "dwBufferLength"), pcm.Length);
                waveOutWrite(hout, outH[wi], HS);
                wi = (wi + 1) % N;
            }
        }

        public void Stop()
        {
            run = false;
            try
            {
                ev.Set();
                if (hin != IntPtr.Zero)
                {
                    waveInReset(hin);
                    if (cap != null) cap.Join(500);
                    for (int i = 0; i < N; i++)
                    {
                        waveInUnprepareHeader(hin, inH[i], HS);
                        var h = (WAVEHDR)Marshal.PtrToStructure(inH[i], typeof(WAVEHDR));
                        Marshal.FreeHGlobal(h.lpData); Marshal.FreeHGlobal(inH[i]);
                    }
                    waveInClose(hin); hin = IntPtr.Zero;
                }
                lock (po)
                {
                    if (hout != IntPtr.Zero)
                    {
                        waveOutReset(hout);
                        for (int i = 0; i < N; i++)
                        {
                            waveOutUnprepareHeader(hout, outH[i], HS);
                            var h = (WAVEHDR)Marshal.PtrToStructure(outH[i], typeof(WAVEHDR));
                            Marshal.FreeHGlobal(h.lpData); Marshal.FreeHGlobal(outH[i]);
                        }
                        waveOutClose(hout); hout = IntPtr.Zero;
                    }
                }
            }
            catch { }
        }
    }
}
