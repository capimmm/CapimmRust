using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Effects;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;

namespace Pulse
{
    // ---------------------------------------------------------------- instalação
    static class Setup
    {
        const string Ver = "4.0.0";
        const string UnKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\capimm-rust";

        public static bool Needed()
        {
            return Get("Setup", "") != Ver;
        }

        public static string Get(string name, string def)
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\capimm-rust"))
                {
                    string v = k == null ? null : k.GetValue(name) as string;
                    return v ?? def;
                }
            }
            catch { return def; }
        }

        public static void Set(string name, string val)
        {
            try { using (var k = Registry.CurrentUser.CreateSubKey(@"Software\capimm-rust")) k.SetValue(name, val); } catch { }
        }

        public static void Install()
        {
            string exe = Process.GetCurrentProcess().MainModule.FileName;
            string dir = System.IO.Path.GetDirectoryName(exe);
            try
            {
                foreach (var folder in new[] { Environment.SpecialFolder.DesktopDirectory, Environment.SpecialFolder.Programs })
                    File.Delete(System.IO.Path.Combine(Environment.GetFolderPath(folder), "Pulse.lnk"));
                Registry.CurrentUser.DeleteSubKeyTree(@"Software\Microsoft\Windows\CurrentVersion\Uninstall\Pulse", false);
                Registry.CurrentUser.DeleteSubKeyTree(@"Software\Pulse", false);
            }
            catch { }
            try
            {
                dynamic sh = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
                foreach (var folder in new[] { Environment.SpecialFolder.DesktopDirectory, Environment.SpecialFolder.Programs })
                {
                    dynamic l = sh.CreateShortcut(System.IO.Path.Combine(Environment.GetFolderPath(folder), "capimm-rust.lnk"));
                    l.TargetPath = exe;
                    l.WorkingDirectory = dir;
                    l.Description = "capimm-rust - música, chat e ligações";
                    l.Save();
                }
            }
            catch { }
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(UnKey))
                {
                    k.SetValue("DisplayName", "capimm-rust");
                    k.SetValue("DisplayVersion", Ver);
                    k.SetValue("Publisher", "capimm-rust");
                    k.SetValue("InstallLocation", dir);
                    k.SetValue("DisplayIcon", exe);
                    k.SetValue("UninstallString", "\"" + exe + "\" --uninstall");
                    k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                }
            }
            catch { }
            Set("Setup", Ver);
        }

        public static void Remove()
        {
            string exe = Process.GetCurrentProcess().MainModule.FileName;
            string dir = System.IO.Path.GetDirectoryName(exe);
            foreach (var folder in new[] { Environment.SpecialFolder.DesktopDirectory, Environment.SpecialFolder.Programs })
            {
                try { File.Delete(System.IO.Path.Combine(Environment.GetFolderPath(folder), "capimm-rust.lnk")); } catch { }
            }
            try { Registry.CurrentUser.DeleteSubKeyTree(UnKey, false); } catch { }
            try { using (var rk = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true)) { if (rk != null) rk.DeleteValue("capimm-rust", false); } } catch { }
            try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\capimm-rust", false); } catch { }
            int me = Process.GetCurrentProcess().Id;
            foreach (var p in Process.GetProcessesByName("capimm-rust"))
            {
                if (p.Id == me) continue;
                try { p.Kill(); } catch { }
            }
            try
            {
                var psi = new ProcessStartInfo("cmd.exe", "/C ping 127.0.0.1 -n 3 >nul & rmdir /s /q \"" + dir + "\"");
                psi.CreateNoWindow = true;
                psi.UseShellExecute = false;
                Process.Start(psi);
            }
            catch { }
        }
    }

    // ---------------------------------------------------------------- modelos de tela
    public class Contact : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        string name; int unread;
        public string Ip;
        public int Port = 7878;
        public bool Saved;
        public DateTime LastSeen = DateTime.MinValue;

        void Raise(string n) { var h = PropertyChanged; if (h != null) h(this, new PropertyChangedEventArgs(n)); }
        public string Name { get { return name; } set { name = value; Raise("Name"); Raise("Initial"); } }
        public string Addr { get { return Ip + ":" + Port; } }
        public string Initial { get { return string.IsNullOrEmpty(name) ? "?" : name.Substring(0, 1).ToUpper(); } }
        public bool Online { get { return (DateTime.Now - LastSeen).TotalSeconds < 15; } }
        public int Unread { get { return unread; } set { unread = value; Refresh(); } }
        public string Sub { get { return unread > 0 ? unread + (unread == 1 ? " nova mensagem" : " novas mensagens") : (Online ? "Na rede agora" : "Salvo"); } }
        public Visibility DotVis { get { return unread > 0 ? Visibility.Visible : Visibility.Collapsed; } }
        public Visibility OnlineVis { get { return Online ? Visibility.Visible : Visibility.Collapsed; } }
        public void Refresh() { Raise("Sub"); Raise("DotVis"); Raise("OnlineVis"); }
    }

    public class Msg
    {
        public string Text { get; set; }
        public HorizontalAlignment Align { get; set; }
        public Brush Bg { get; set; }
        public Brush Fg { get; set; }
    }

    // ---------------------------------------------------------------- janela principal
    partial class MainWin
    {
        const int Port = 7878;
        public Window W;
        Server server = new Server();
        Discovery disc = new Discovery();
        MediaPlayer mp = new MediaPlayer();
        List<Item> lib = new List<Item>();
        List<Item> queue = new List<Item>();
        int qi = -1;
        ObservableCollection<Contact> contacts = new ObservableCollection<Contact>();
        Dictionary<string, ObservableCollection<Msg>> convs = new Dictionary<string, ObservableCollection<Msg>>();
        Contact sel;
        DispatcherTimer timer, eqTimer, searchTimer, friendTimer, callTimer, ringTimer;
        Random rnd = new Random();
        bool playing, hasSource, seeking, eqIdle = true;
        double seekRatio, vol = 0.8;
        TimeSpan dur = TimeSpan.Zero;
        Grid[] pages;
        int curPage = -1, searchId, callId, playId;
        bool srcLoaded;
        // ligação
        CallSession sess; Voice voice; bool muted, active; DateTime callStart;
        static readonly Brush MineBg = Brushes.White;
        static readonly Brush MineFg = Brushes.Black;
        static readonly Brush TheirBg = Fz(new SolidColorBrush(Color.FromArgb(0x30, 255, 255, 255)));
        static readonly Brush TheirFg = Brushes.White;
        static readonly Brush NoteFg = Fz(new SolidColorBrush(Color.FromArgb(0x99, 255, 255, 255)));

        static Brush Fz(SolidColorBrush b) { b.Freeze(); return b; }
        readonly Dictionary<string, object> fcache = new Dictionary<string, object>();
        T F<T>(string n) where T : class
        {
            object o;
            if (!fcache.TryGetValue(n, out o)) { o = W.FindName(n); fcache[n] = o; }
            return o as T;
        }
        void Ui(Action a) { W.Dispatcher.BeginInvoke(a); }
        string Nick() { string n = F<TextBox>("NickBox").Text.Trim(); return n.Length == 0 ? Environment.UserName : n; }

        static bool OnButton(DependencyObject d)
        {
            while (d != null)
            {
                if (d is System.Windows.Controls.Primitives.ButtonBase) return true;
                d = (d is Visual) ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
            }
            return false;
        }

        public void Build()
        {
            using (var s = typeof(MainWin).Assembly.GetManifestResourceStream("Ui.xaml"))
                W = (Window)XamlReader.Load(s);
            pages = new[] { F<Grid>("PgSearch"), F<Grid>("PgLib"), F<Grid>("PgCmr"), F<Grid>("PgFriends"), F<Grid>("PgServers"), F<Grid>("PgSettings") };
            W.Loaded += delegate { OnLoaded(); };
            W.Closing += delegate { try { mp.Stop(); } catch { } if (voice != null) voice.Stop(); };

            F<Grid>("TitleDrag").MouseLeftButtonDown += (s, e) => { if (e.ClickCount == 1 && !OnButton(e.OriginalSource as DependencyObject)) { try { W.DragMove(); } catch { } } };
            F<Button>("BtnMin").Click += delegate { W.WindowState = WindowState.Minimized; };
            F<Button>("BtnClose").Click += delegate { W.Close(); };
            F<RadioButton>("NavSearch").Checked += delegate { ShowPage(0); };
            F<RadioButton>("NavLib").Checked += delegate { ShowPage(1); };
            F<RadioButton>("NavCmr").Checked += delegate { ShowPage(2); };
            F<RadioButton>("NavFriends").Checked += delegate { ShowPage(3); };
            F<RadioButton>("NavServers").Checked += delegate { ShowPage(4); };
            F<RadioButton>("NavSettings").Checked += delegate { ShowPage(5); };

            // arrastar arquivos/pastas/playlists para importar
            W.DragOver += (s, e) => { e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None; e.Handled = true; };
            W.Drop += (s, e) => { if (e.Data.GetDataPresent(DataFormats.FileDrop)) ImportPaths((string[])e.Data.GetData(DataFormats.FileDrop)); };

            server.Share = Setup.Get("Share", "1") == "1";
            server.Dnd = Setup.Get("Dnd", "0") == "1";
            BuildPlayer();
            BuildSearch();
            BuildLibrary();
            BuildFriends();
            BuildCall();
            BuildExtras();

            server.Dir = Util.LibDir;
            server.MyNick = () => (string)W.Dispatcher.Invoke(new Func<string>(Nick));
            server.OnDM = (ip, port, nick, text) => Ui(() => ReceiveDM(ip, port, nick, text));
            server.OnCall = (ip, port, s) => Ui(() => IncomingCall(ip, port, s));
            disc.Nick = () => (string)W.Dispatcher.Invoke(new Func<string>(Nick));
            disc.OnPeer = (ip, nick, port) => Ui(() => Peer(ip, nick, port));
            ReloadLib();

            // ícone e logo (capimm-rust)
            try
            {
                var lg = Png("logo.png");
                F<Image>("LogoTitle").Source = lg;
                F<Image>("LogoSplash").Source = lg;
                using (var st = Res("app.ico")) W.Icon = BitmapFrame.Create(st, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            }
            catch (Exception ex) { Util.Log(ex); }
            // cantos arredondados: recorta todo o conteúdo no formato da janela
            var inner = F<Grid>("Inner");
            inner.SizeChanged += (s, e) => { inner.Clip = new RectangleGeometry(new Rect(0, 0, inner.ActualWidth, inner.ActualHeight), 27, 27); };
        }

        static Stream Res(string n) { return typeof(MainWin).Assembly.GetManifestResourceStream(n); }
        static BitmapImage Png(string n)
        {
            var bi = new BitmapImage();
            bi.BeginInit();
            bi.CacheOption = BitmapCacheOption.OnLoad;
            bi.StreamSource = Res(n);
            bi.EndInit();
            bi.Freeze();
            return bi;
        }

        // ---------------- animações (blur + mola, estilo iOS 26 / HyperOS)
        void OnLoaded()
        {
            var spring = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.55 };
            F<Border>("Root").BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(450)));
            var sc = (ScaleTransform)F<Border>("Root").RenderTransform;
            var da = new DoubleAnimation(0.93, 1, TimeSpan.FromMilliseconds(700)) { EasingFunction = spring };
            sc.BeginAnimation(ScaleTransform.ScaleXProperty, da);
            sc.BeginAnimation(ScaleTransform.ScaleYProperty, da);
            ApplyPerf();
            F<Border>("VolFill").Height = F<FrameworkElement>("VolHost").ActualHeight * vol;
            // tela de carregamento: logo entra com mola, anel gira, brilho pulsa
            var ls = F<ScaleTransform>("SplashLogoScale");
            var la = new DoubleAnimation(0.4, 1, TimeSpan.FromMilliseconds(900)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.8 } };
            ls.BeginAnimation(ScaleTransform.ScaleXProperty, la);
            ls.BeginAnimation(ScaleTransform.ScaleYProperty, la);
            F<RotateTransform>("SplashSpin").BeginAnimation(RotateTransform.AngleProperty, new DoubleAnimation(0, 360, TimeSpan.FromSeconds(6)) { RepeatBehavior = RepeatBehavior.Forever });
            var gl = (ScaleTransform)F<System.Windows.Shapes.Ellipse>("SplashGlow").RenderTransform;
            var ga = new DoubleAnimation(0.9, 1.12, TimeSpan.FromSeconds(2.2)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut } };
            gl.BeginAnimation(ScaleTransform.ScaleXProperty, ga);
            gl.BeginAnimation(ScaleTransform.ScaleYProperty, ga);
            ShowPage(0);
            DoSearch("");
            Boot();
        }

        // conecta tudo automaticamente enquanto mostra o progresso real
        void Boot()
        {
            bool needSetup = Setup.Needed();
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    string tmp = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "capimm-rust");
                    if (Directory.Exists(tmp)) foreach (var f in Directory.GetFiles(tmp)) { try { File.Delete(f); } catch { } }
                }
                catch { }
                Thread.Sleep(700);
                Ui(() => StepStart(1));
                string err = null;
                try { server.Start(Port); } catch (Exception ex) { err = ex.Message; Util.Log(ex); }
                Thread.Sleep(700);
                Ui(() => StepDone(1, err == null ? "Servidor ativo na porta " + Port : "Servidor indisponível (porta em uso)"));
                Ui(() => StepStart(2));
                if (needSetup) { try { Setup.Install(); } catch (Exception ex) { Util.Log(ex); } }
                string ip = LocalIp();
                Thread.Sleep(700);
                Ui(() => StepDone(2, "Seu endereço: " + ip));
                Ui(() => StepStart(3));
                try { disc.Start(Port); } catch (Exception ex) { Util.Log(ex); }
                Thread.Sleep(2400);
                Ui(() =>
                {
                    int n = 0;
                    foreach (var c in contacts) if (c.Online) n++;
                    StepDone(3, n == 0 ? "Ninguém por perto agora (use um código)" : n + (n == 1 ? " amigo na rede" : " amigos na rede"));
                    F<TextBlock>("SplashStatus").Text = "Tudo conectado";
                });
                Thread.Sleep(900);
                Ui(HideSplash);
            });
        }

        void StepStart(int i)
        {
            var r = F<Grid>("R" + i);
            r.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(1, TimeSpan.FromMilliseconds(350)));
            F<System.Windows.Shapes.Ellipse>("D" + i).Fill = new SolidColorBrush(Color.FromArgb(0x66, 255, 255, 255));
            var f = F<Border>("SplashFill");
            f.BeginAnimation(FrameworkElement.WidthProperty, new DoubleAnimation(300.0 * (i - 1) / 3.0 + 40, TimeSpan.FromMilliseconds(600)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        }

        void StepDone(int i, string text)
        {
            F<System.Windows.Shapes.Ellipse>("D" + i).Fill = Brushes.White;
            F<TextBlock>("T" + i).Text = text;
            var f = F<Border>("SplashFill");
            f.BeginAnimation(FrameworkElement.WidthProperty, new DoubleAnimation(300.0 * i / 3.0, TimeSpan.FromMilliseconds(600)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        }

        void HideSplash()
        {
            var sp = F<Grid>("Splash");
            curPage = -1;
            ShowPage(0); // a tela principal entra enquanto o carregamento some
            var blur = new BlurEffect { Radius = 0 };
            sp.Effect = blur;
            blur.BeginAnimation(BlurEffect.RadiusProperty, new DoubleAnimation(0, 24, TimeSpan.FromMilliseconds(650)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } });
            var a = new DoubleAnimation(0, TimeSpan.FromMilliseconds(650)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } };
            a.Completed += (s, e) => { sp.Visibility = Visibility.Collapsed; sp.Effect = null; };
            sp.BeginAnimation(UIElement.OpacityProperty, a);
            var st = new ScaleTransform(1, 1);
            sp.RenderTransformOrigin = new Point(0.5, 0.5);
            sp.RenderTransform = st;
            var za = new DoubleAnimation(1, 1.06, TimeSpan.FromMilliseconds(650)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } };
            st.BeginAnimation(ScaleTransform.ScaleXProperty, za);
            st.BeginAnimation(ScaleTransform.ScaleYProperty, za);
        }

        // lista que entra em cascata (cada linha sobe e aparece em sequência)
        void SetItems(ListBox lb, System.Collections.IEnumerable src)
        {
            lb.ItemsSource = src;
            EventHandler h = null;
            h = (s, e) =>
            {
                if (lb.ItemContainerGenerator.Status != System.Windows.Controls.Primitives.GeneratorStatus.ContainersGenerated) return;
                lb.ItemContainerGenerator.StatusChanged -= h;
                int n = perf == 2 ? 0 : Math.Min(lb.Items.Count, perf == 0 ? 16 : 8);
                for (int i = 0; i < n; i++)
                {
                    var c = lb.ItemContainerGenerator.ContainerFromIndex(i) as FrameworkElement;
                    if (c == null) continue;
                    var tt = new TranslateTransform(0, 20);
                    c.RenderTransform = tt;
                    c.Opacity = 0;
                    var bt = TimeSpan.FromMilliseconds(45 * i);
                    tt.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(20, 0, TimeSpan.FromMilliseconds(520)) { BeginTime = bt, EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.35 } });
                    c.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(380)) { BeginTime = bt });
                }
            };
            lb.ItemContainerGenerator.StatusChanged += h;
        }

        static void Drift(TranslateTransform t, double x, double y, double sx, double sy)
        {
            var e = new SineEase { EasingMode = EasingMode.EaseInOut };
            var ax = new DoubleAnimation(0, x, TimeSpan.FromSeconds(sx)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = e };
            var ay = new DoubleAnimation(0, y, TimeSpan.FromSeconds(sy)) { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = e };
            Timeline.SetDesiredFrameRate(ax, 30);
            Timeline.SetDesiredFrameRate(ay, 30);
            t.BeginAnimation(TranslateTransform.XProperty, ax);
            t.BeginAnimation(TranslateTransform.YProperty, ay);
        }

        void ShowPage(int idx)
        {
            if (pages == null || idx == curPage) return;
            curPage = idx;
            var thumb = F<Border>("NavThumb");
            double w = (thumb.Parent as FrameworkElement).ActualWidth / 6.0;
            if (w > 0)
            {
                thumb.Width = w;
                ((TranslateTransform)thumb.RenderTransform).BeginAnimation(TranslateTransform.XProperty,
                    new DoubleAnimation(idx * w, TimeSpan.FromMilliseconds(perf == 2 ? 1 : 520)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.4 } });
            }
            for (int i = 0; i < pages.Length; i++) if (i != idx) pages[i].Visibility = Visibility.Collapsed;
            var pg = pages[idx];
            pg.Visibility = Visibility.Visible;
            pg.Effect = null;
            if (perf == 2)
            {
                pg.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(140)));
            }
            else
            {
                var tg = (TransformGroup)pg.RenderTransform;
                var sc = (ScaleTransform)tg.Children[0];
                var tt = (TranslateTransform)tg.Children[1];
                var smooth = new CubicEase { EasingMode = EasingMode.EaseOut };
                if (FxFull)
                {
                    var blur = new BlurEffect { Radius = 28 };
                    pg.Effect = blur;
                    var ba = new DoubleAnimation(28, 0, TimeSpan.FromMilliseconds(560)) { EasingFunction = smooth };
                    ba.Completed += (s, e) => { if (pages[curPage] == pg) pg.Effect = null; };
                    blur.BeginAnimation(BlurEffect.RadiusProperty, ba);
                }
                var sa = new DoubleAnimation(0.94, 1, TimeSpan.FromMilliseconds(620)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.3 } };
                sc.BeginAnimation(ScaleTransform.ScaleXProperty, sa);
                sc.BeginAnimation(ScaleTransform.ScaleYProperty, sa);
                tt.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(24, 0, TimeSpan.FromMilliseconds(560)) { EasingFunction = smooth });
                pg.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(420)));
            }
            if (idx == 1 && !srcLoaded) { srcLoaded = true; LoadSources(); }
            if (idx == 2 && (DateTime.Now - cmrLast).TotalSeconds > 45) RefreshCmr();
            if (idx == 3 && sel != null) { sel.Unread = 0; }
        }

        void FadeIn(UIElement e)
        {
            e.Visibility = Visibility.Visible;
            e.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(320)));
        }

        void Toast(string msg)
        {
            F<TextBlock>("ToastText").Text = msg;
            var t = F<Border>("Toast");
            var a = new DoubleAnimationUsingKeyFrames();
            a.KeyFrames.Add(new EasingDoubleKeyFrame(1, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(320)), new CubicEase { EasingMode = EasingMode.EaseOut }));
            a.KeyFrames.Add(new LinearDoubleKeyFrame(1, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(3000))));
            a.KeyFrames.Add(new EasingDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(3450)), new CubicEase { EasingMode = EasingMode.EaseIn }));
            t.BeginAnimation(UIElement.OpacityProperty, a);
            var y = new DoubleAnimationUsingKeyFrames();
            y.KeyFrames.Add(new EasingDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(500)), new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.8 }));
            y.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(3000))));
            y.KeyFrames.Add(new EasingDoubleKeyFrame(-14, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(3450)), new CubicEase { EasingMode = EasingMode.EaseIn }));
            F<TranslateTransform>("ToastT").BeginAnimation(TranslateTransform.YProperty, y);
        }

        // ---------------- player
        static string Fmt(TimeSpan t) { return ((int)t.TotalMinutes) + ":" + t.Seconds.ToString("00"); }

        void BuildPlayer()
        {
            F<Button>("BtnPlay").Click += delegate { Toggle(); };
            F<Button>("BtnNext").Click += delegate { Next(); };
            F<Button>("BtnPrev").Click += delegate { Prev(); };
            var seek = F<Grid>("SeekHost");
            seek.MouseLeftButtonDown += (s, e) => { seeking = true; seek.CaptureMouse(); SeekMove(e.GetPosition(seek).X); };
            seek.MouseMove += (s, e) => { if (seeking) SeekMove(e.GetPosition(seek).X); };
            seek.MouseLeftButtonUp += (s, e) =>
            {
                if (!seeking) return;
                seeking = false; seek.ReleaseMouseCapture();
                if (hasSource && dur.TotalSeconds > 0) mp.Position = TimeSpan.FromSeconds(dur.TotalSeconds * seekRatio);
            };
            var vh = F<FrameworkElement>("VolHost");
            vh.MouseLeftButtonDown += (s, e) => { vh.CaptureMouse(); SetVol(1 - e.GetPosition(vh).Y / vh.ActualHeight); };
            vh.MouseMove += (s, e) => { if (vh.IsMouseCaptured) SetVol(1 - e.GetPosition(vh).Y / vh.ActualHeight); };
            vh.MouseLeftButtonUp += (s, e) => vh.ReleaseMouseCapture();
            InitPlayer();
            timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
            timer.Tick += delegate { Tick(); };
            timer.Start();
            eqTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(150) };
            eqTimer.Tick += delegate { Eq(); };
            eqTimer.Start();
        }

        void InitPlayer()
        {
            mp = new MediaPlayer();
            mp.Volume = vol;
            mp.MediaOpened += delegate
            {
                if (mp.NaturalDuration.HasTimeSpan) { dur = mp.NaturalDuration.TimeSpan; F<TextBlock>("TimeTot").Text = Fmt(dur); }
            };
            mp.MediaEnded += delegate { OnEnded(); };
            mp.MediaFailed += (s, e) => { playing = false; UpdateIcon(); if (e.ErrorException != null) Util.Log(e.ErrorException); Toast("Não consegui tocar esta faixa"); };
        }

        void PlayFrom(List<Item> list, int idx)
        {
            if (list == null || idx < 0 || idx >= list.Count) return;
            queue = list; qi = idx;
            PlayItem(list[idx]);
        }

        void PlayItem(Item it)
        {
            int id = ++playId;
            try
            {
                F<TextBlock>("NowTitle").Text = it.Name;
                F<TextBlock>("NowArtist").Text = it.Artist ?? "";
                if (perf < 2)
                {
                    var box = (ScaleTransform)F<Border>("NowCoverBox").RenderTransform;
                    var pop = new DoubleAnimation(0.8, 1, TimeSpan.FromMilliseconds(560)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.9 } };
                    box.BeginAnimation(ScaleTransform.ScaleXProperty, pop);
                    box.BeginAnimation(ScaleTransform.ScaleYProperty, pop);
                }
                SetCover(it);
                if (island != null) island.Update(it.Name, it.Artist ?? "");
            }
            catch (Exception ex) { Util.Log(ex); }
            if (it.Path != null) { StartMedia(it.Path); return; }
            PlayRemote(it, id);
        }

        void StartMedia(string path)
        {
            try
            {
                try { mp.Open(new Uri(path, UriKind.Absolute)); }
                catch (NullReferenceException) { InitPlayer(); mp.Open(new Uri(path, UriKind.Absolute)); }
                mp.Volume = vol;
                mp.Play();
                playing = true; hasSource = true; dur = TimeSpan.Zero;
                F<TextBlock>("TimeTot").Text = "0:00";
                var f = F<Border>("SeekFill");
                f.BeginAnimation(FrameworkElement.WidthProperty, null);
                f.Width = 0;
                UpdateIcon();
            }
            catch (Exception ex)
            {
                Util.Log(ex);
                Toast("Erro ao tocar: " + ex.Message);
            }
        }

        void Next() { NextTrack(); }
                void Prev() { if (queue.Count == 0) return; qi = (qi + queue.Count - 1) % queue.Count; PlayItem(queue[qi]); }

        void Toggle()
        {
            if (!hasSource) { if (lib.Count > 0) PlayFrom(lib, 0); return; }
            if (playing) { mp.Pause(); playing = false; } else { mp.Play(); playing = true; }
            UpdateIcon();
        }

        void UpdateIcon()
        {
            var ic = F<System.Windows.Shapes.Path>("PlayIcon");
            ic.Data = Geometry.Parse(playing ? Geo.Pause : Geo.Play);
            OnPlayState();
            var sc = (ScaleTransform)ic.RenderTransform;
            var a = new DoubleAnimation(0.5, 1, TimeSpan.FromMilliseconds(420)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 1.0 } };
            sc.BeginAnimation(ScaleTransform.ScaleXProperty, a);
            sc.BeginAnimation(ScaleTransform.ScaleYProperty, a);
        }

        void SeekMove(double x)
        {
            var host = F<Grid>("SeekHost");
            seekRatio = Math.Max(0, Math.Min(1, x / host.ActualWidth));
            var f = F<Border>("SeekFill");
            f.BeginAnimation(FrameworkElement.WidthProperty, null);
            f.Width = seekRatio * host.ActualWidth;
            if (dur.TotalSeconds > 0) F<TextBlock>("TimeCur").Text = Fmt(TimeSpan.FromSeconds(dur.TotalSeconds * seekRatio));
        }

        void SetVol(double r)
        {
            vol = Math.Max(0, Math.Min(1, r));
            mp.Volume = vol;
            F<Border>("VolFill").Height = vol * F<FrameworkElement>("VolHost").ActualHeight;
        }

        void Tick()
        {
            if (!hasSource || seeking || dur.TotalSeconds <= 0) return;
            double r = Math.Min(1, mp.Position.TotalSeconds / dur.TotalSeconds);
            var sf = F<Border>("SeekFill");
            double wv = r * F<Grid>("SeekHost").ActualWidth;
            if (perf == 0) sf.BeginAnimation(FrameworkElement.WidthProperty, new DoubleAnimation(wv, TimeSpan.FromMilliseconds(280)));
            else { sf.BeginAnimation(FrameworkElement.WidthProperty, null); sf.Width = wv; }
            F<TextBlock>("TimeCur").Text = Fmt(mp.Position);
            if (island != null) island.Progress(r);
        }

        void Eq() { WaveTick(); }

        static Item ItemUnder(ListBox lb, MouseButtonEventArgs e)
        {
            try
            {
                var d = e.OriginalSource as DependencyObject;
                if (d == null || OnButton(d)) return null;
                var c = ItemsControl.ContainerFromElement(lb, d) as ListBoxItem;
                return c == null ? null : c.DataContext as Item;
            }
            catch { return null; }
        }

        void ClickPlay(ListBox lb)
        {
            lb.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var it = ItemUnder(lb, e);
                var list = lb.ItemsSource as List<Item>;
                if (it != null && list != null) PlayFrom(list, list.IndexOf(it));
            };
        }

        // ---------------- buscar (resultados aparecem enquanto digita)
        void BuildSearch()
        {
            ClickPlay(F<ListBox>("LocalRes"));
            ClickPlay(F<ListBox>("OnlineRes"));
            searchTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(380) };
            searchTimer.Tick += delegate { searchTimer.Stop(); DoSearch(F<TextBox>("SearchBox").Text.Trim()); };
            F<TextBox>("SearchBox").TextChanged += delegate { searchTimer.Stop(); searchTimer.Start(); };
        }

        void DoSearch(string q)
        {
            // biblioteca: instantâneo
            var local = new List<Item>();
            foreach (var i in lib)
                if (q.Length > 0 && (i.Name.IndexOf(q, StringComparison.CurrentCultureIgnoreCase) >= 0)) local.Add(i);
            SetItems(F<ListBox>("LocalRes"), local);
            F<TextBlock>("LocalHeader").Visibility = local.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            SearchOnline(q);
        }

        // ---------------- biblioteca + importar de outros apps
        void BuildLibrary()
        {
            ClickPlay(F<ListBox>("LibList"));
            F<Button>("BtnImpFiles").Click += delegate
            {
                var dlg = new OpenFileDialog { Multiselect = true, Title = "Importar músicas ou playlists", Filter = "Músicas e playlists|*.mp3;*.flac;*.wav;*.ogg;*.m4a;*.aac;*.wma;*.m3u;*.m3u8;*.pls|Todos os arquivos|*.*" };
                if (dlg.ShowDialog(W) == true) ImportPaths(dlg.FileNames);
            };
            F<Button>("BtnImpFolder").Click += delegate
            {
                using (var dlg = new System.Windows.Forms.FolderBrowserDialog())
                {
                    dlg.Description = "Escolha a pasta com suas músicas";
                    if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK) ImportPaths(new[] { dlg.SelectedPath });
                }
            };
            F<ListBox>("SrcList").AddHandler(Button.ClickEvent, new RoutedEventHandler((s, e) =>
            {
                var b = e.OriginalSource as Button;
                var src = b == null ? null : b.DataContext as Source;
                if (src != null) ImportPaths(new[] { src.Path });
            }));
        }

        void ReloadLib()
        {
            lib = Util.Tracks(Util.LibDir);
            SetItems(F<ListBox>("LibList"), lib);
            F<TextBlock>("LibEmpty").Visibility = (lib.Count == 0 && F<Grid>("LibPl").Visibility != Visibility.Visible) ? Visibility.Visible : Visibility.Collapsed;
        }

        void LoadSources()
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                string music = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);
                string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                string skip = Util.LibDir;
                var cand = new[]
                {
                    new Source { Label = "Pasta Músicas do Windows", Path = music },
                    new Source { Label = "iTunes / Apple Music", Path = System.IO.Path.Combine(music, @"iTunes\iTunes Media") },
                    new Source { Label = "Amazon Music", Path = System.IO.Path.Combine(music, "Amazon Music") },
                    new Source { Label = "Downloads", Path = System.IO.Path.Combine(home, "Downloads") },
                    new Source { Label = "Área de trabalho", Path = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) }
                };
                var found = new List<Source>();
                foreach (var c in cand)
                {
                    if (!Directory.Exists(c.Path)) continue;
                    var acc = new List<string>();
                    Util.Collect(c.Path, acc, 3000, 0, skip);
                    if (acc.Count == 0) continue;
                    c.CountText = (acc.Count >= 3000 ? "3000+" : acc.Count.ToString()) + " músicas";
                    found.Add(c);
                }
                Ui(() => SetItems(F<ListBox>("SrcList"), found));
            });
        }

        void ImportPaths(string[] paths)
        {
            Toast("Importando…");
            ThreadPool.QueueUserWorkItem(delegate
            {
                var files = new List<string>();
                string lib2 = Util.LibDir;
                foreach (var p in paths)
                {
                    try
                    {
                        if (Directory.Exists(p)) Util.Collect(p, files, 20000, 0, lib2);
                        else if (Util.IsPlaylist(p)) files.AddRange(Util.ReadPlaylist(p));
                        else if (Util.IsAudio(p)) files.Add(p);
                    }
                    catch { }
                }
                int ok = 0;
                foreach (var f in files)
                {
                    try
                    {
                        string dest = System.IO.Path.Combine(lib2, System.IO.Path.GetFileName(f));
                        if (!File.Exists(f) || File.Exists(dest)) continue;
                        File.Copy(f, dest);
                        ok++;
                    }
                    catch { }
                }
                Ui(() => { ReloadLib(); Toast(ok == 0 ? "Nada novo para importar" : ok + (ok == 1 ? " música importada" : " músicas importadas")); });
            });
        }

        // ---------------- amigos: conectar, conversar e ligar
        void BuildFriends()
        {
            var nick = F<TextBox>("NickBox");
            nick.Text = Setup.Get("Nick", Environment.UserName);
            nick.TextChanged += delegate { Setup.Set("Nick", nick.Text); };
            F<TextBlock>("MyCode").Text = Util.MakeCode(LocalIp(), Port);
            F<Button>("BtnCopyCode").Click += delegate { try { Clipboard.SetText(F<TextBlock>("MyCode").Text); Toast("Código copiado"); } catch { } };
            F<Button>("BtnAddCode").Click += delegate { AddByCode(); };
            F<TextBox>("CodeBox").KeyDown += (s, e) => { if (e.Key == Key.Enter) AddByCode(); };

            LoadContacts();
            var cl = F<ListBox>("ContactList");
            cl.ItemsSource = contacts;
            cl.SelectionChanged += delegate { var c = cl.SelectedItem as Contact; if (c != null) OpenConv(c); };

            var mb = F<TextBox>("MsgBox");
            mb.KeyDown += (s, e) => { if (e.Key == Key.Enter) SendMsg(); };
            F<Button>("BtnSend").Click += delegate { SendMsg(); };
            F<Button>("BtnCall").Click += delegate { if (sel != null) Dial(sel); };
            F<Button>("BtnMusic").Click += delegate { OpenMusic(); };
            F<Button>("BtnRemBack").Click += delegate { F<Grid>("MusicPane").Visibility = Visibility.Collapsed; };
            F<Button>("BtnRemImport").Click += delegate
            {
                var it = F<ListBox>("RemList").SelectedItem as Item;
                if (it == null) { Toast("Selecione uma música da lista"); return; }
                ImportRemote(new List<Item> { it });
            };
            F<Button>("BtnRemAll").Click += delegate
            {
                var all = F<ListBox>("RemList").ItemsSource as List<Item>;
                if (all != null && all.Count > 0) ImportRemote(all);
            };

            friendTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(4) };
            friendTimer.Tick += delegate
            {
                for (int i = contacts.Count - 1; i >= 0; i--)
                {
                    var c = contacts[i];
                    if (!c.Saved && !c.Online && c != sel && c.Unread == 0) { contacts.RemoveAt(i); continue; }
                    c.Refresh();
                }
                if (sel != null) F<TextBlock>("ChatSub").Text = sel.Online ? "Na rede agora" : sel.Addr;
            };
            friendTimer.Start();
        }

        void LoadContacts()
        {
            foreach (var part in Setup.Get("Contacts", "").Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string[] kv = part.Split('|');
                if (kv.Length != 2) continue;
                string a = Util.ParseCode(kv[1]);
                if (a == null) continue;
                int i = a.LastIndexOf(':');
                int port; int.TryParse(a.Substring(i + 1), out port);
                contacts.Add(new Contact { Name = kv[0], Ip = a.Substring(0, i), Port = port, Saved = true });
            }
        }

        void SaveContacts()
        {
            var sb = new System.Text.StringBuilder();
            foreach (var c in contacts)
                if (c.Saved) sb.Append(c.Name.Replace('|', ' ').Replace(';', ' ')).Append('|').Append(c.Addr).Append(';');
            Setup.Set("Contacts", sb.ToString());
        }

        Contact Find(string ip)
        {
            foreach (var c in contacts) if (c.Ip == ip) return c;
            return null;
        }

        Contact Ensure(string ip, int port, string name, bool save)
        {
            var c = Find(ip);
            if (c == null)
            {
                c = new Contact { Name = name, Ip = ip, Port = port, Saved = save };
                contacts.Add(c);
                if (save) SaveContacts();
            }
            else
            {
                if (port > 0) c.Port = port;
                if (!string.IsNullOrEmpty(name) && c.Name != name) { c.Name = name; if (c.Saved) SaveContacts(); }
                if (save && !c.Saved) { c.Saved = true; SaveContacts(); }
            }
            return c;
        }

        void Peer(string ip, string nick, int port)
        {
            var c = Ensure(ip, port, nick, false);
            c.LastSeen = DateTime.Now;
            c.Refresh();
        }

        void AddByCode()
        {
            var box = F<TextBox>("CodeBox");
            string addr = Util.ParseCode(box.Text);
            if (addr == null) { Toast("Código inválido"); return; }
            int i = addr.LastIndexOf(':');
            string ip = addr.Substring(0, i);
            int port; int.TryParse(addr.Substring(i + 1), out port);
            box.Clear();
            Toast("Procurando amigo…");
            ThreadPool.QueueUserWorkItem(delegate
            {
                string name = null;
                try { name = Client.Hello(addr); } catch { }
                Ui(() =>
                {
                    var c = Ensure(ip, port, name ?? "Amigo " + ip, true);
                    if (name != null) c.LastSeen = DateTime.Now;
                    c.Refresh();
                    F<ListBox>("ContactList").SelectedItem = c;
                    Toast(name != null ? "Conectado com " + name : "Amigo salvo (está offline agora)");
                });
            });
        }

        ObservableCollection<Msg> Conv(string ip)
        {
            ObservableCollection<Msg> m;
            if (!convs.TryGetValue(ip, out m)) { m = new ObservableCollection<Msg>(); convs[ip] = m; }
            return m;
        }

        void OpenConv(Contact c)
        {
            sel = c;
            c.Unread = 0;
            F<StackPanel>("ChatEmpty").Visibility = Visibility.Collapsed;
            var pane = F<Grid>("ChatPane");
            if (pane.Visibility != Visibility.Visible) FadeIn(pane);
            F<TextBlock>("ChatName").Text = c.Name;
            F<TextBlock>("ChatInitial").Text = c.Initial;
            F<TextBlock>("ChatSub").Text = c.Online ? "Na rede agora" : c.Addr;
            F<ListBox>("MsgList").ItemsSource = Conv(c.Ip);
            F<Grid>("MusicPane").Visibility = Visibility.Collapsed;
            ScrollEnd();
            F<TextBox>("MsgBox").Focus();
        }

        void ScrollEnd()
        {
            var l = Conv(sel == null ? "" : sel.Ip);
            if (l.Count > 0) F<ListBox>("MsgList").ScrollIntoView(l[l.Count - 1]);
        }

        void AddMsg(Contact c, bool mine, string text)
        {
            var m = new Msg { Text = text, Align = mine ? HorizontalAlignment.Right : HorizontalAlignment.Left, Bg = mine ? MineBg : TheirBg, Fg = mine ? MineFg : TheirFg };
            Conv(c.Ip).Add(m);
            if (c == sel) ScrollEnd();
        }

        void AddNote(Contact c, string text)
        {
            Conv(c.Ip).Add(new Msg { Text = text, Align = HorizontalAlignment.Center, Bg = Brushes.Transparent, Fg = NoteFg });
            if (c == sel) ScrollEnd();
        }

        void SendMsg()
        {
            var box = F<TextBox>("MsgBox");
            string text = box.Text.Trim();
            if (text.Length == 0 || sel == null) return;
            var c = sel;
            box.Clear();
            AddMsg(c, true, text);
            string nick = Nick(), addr = c.Addr;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try { Client.SendDM(addr, nick, Port, text); }
                catch (Exception ex) { Ui(() => AddNote(c, "Não entregue: " + ex.Message)); }
            });
        }

        void ReceiveDM(string ip, int port, string nick, string text)
        {
            var c = Ensure(ip, port, nick, true);
            c.LastSeen = DateTime.Now;
            AddMsg(c, false, text);
            if (c != sel || curPage != 3 || !W.IsActive)
            {
                c.Unread++;
                if (Cfg("notif", true)) { Toast(c.Name + ": " + text); Notify(c.Name + ": " + text); }
            }
        }

        void OpenMusic()
        {
            if (sel == null) return;
            var c = sel;
            Toast("Abrindo a biblioteca de " + c.Name + "…");
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    var r = Client.List(c.Addr);
                    Ui(() =>
                    {
                        F<ListBox>("RemList").ItemsSource = r;
                        FadeIn(F<Grid>("MusicPane"));
                        Toast(r.Count + " músicas disponíveis");
                    });
                }
                catch (Exception ex) { Ui(() => Toast("Falha: " + ex.Message)); }
            });
        }

        void ImportRemote(List<Item> items)
        {
            if (sel == null) return;
            string addr = sel.Addr;
            var names = new List<string>();
            foreach (var i in items) names.Add(i.Artist); // Artist guarda o nome do arquivo
            Toast("Importando " + names.Count + (names.Count == 1 ? " música…" : " músicas…"));
            ThreadPool.QueueUserWorkItem(delegate
            {
                int ok = 0;
                foreach (var n in names)
                {
                    try
                    {
                        string safe = Util.SafeName(n);
                        if (safe == null) continue;
                        string dest = System.IO.Path.Combine(Util.LibDir, safe);
                        if (File.Exists(dest)) continue;
                        Client.Download(addr, safe, dest);
                        ok++;
                    }
                    catch { }
                }
                Ui(() => { ReloadLib(); Toast(ok == 0 ? "Nada novo para importar" : ok + " importadas para a biblioteca"); });
            });
        }

        // ---------------- tela de ligação
        void BuildCall()
        {
            F<Button>("BtnCancelCall").Click += delegate { EndCall("Cancelada"); };
            F<Button>("BtnDecline").Click += delegate { if (sess != null) sess.Decline(); EndCall(null); };
            F<Button>("BtnAccept").Click += delegate { AcceptCall(); };
            F<Button>("BtnHang").Click += delegate { EndCall("Ligação encerrada"); };
            F<Button>("BtnMute").Click += delegate
            {
                muted = !muted;
                F<Button>("BtnMute").Background = muted ? Brushes.White : new SolidColorBrush(Color.FromArgb(0x20, 255, 255, 255));
                F<System.Windows.Shapes.Path>("MuteIcon").Fill = muted ? Brushes.Black : Brushes.White;
                F<TextBlock>("MuteLabel").Text = muted ? "Mudo ligado" : "Mudo";
            };
            callTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            callTimer.Tick += delegate { if (active) F<TextBlock>("CallStatus").Text = Fmt(DateTime.Now - callStart); };
            ringTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(2200) };
            ringTimer.Tick += delegate { try { System.Media.SystemSounds.Exclamation.Play(); } catch { } };
            // anéis pulsando
            string[] rings = { "Ring1", "Ring2", "Ring3" };
            for (int i = 0; i < 3; i++)
            {
                var sc = (ScaleTransform)F<System.Windows.Shapes.Ellipse>(rings[i]).RenderTransform;
                var el = F<System.Windows.Shapes.Ellipse>(rings[i]);
                var grow = new DoubleAnimation(1, 1.75, TimeSpan.FromSeconds(2.4)) { RepeatBehavior = RepeatBehavior.Forever, BeginTime = TimeSpan.FromSeconds(0.8 * i), EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
                sc.BeginAnimation(ScaleTransform.ScaleXProperty, grow);
                sc.BeginAnimation(ScaleTransform.ScaleYProperty, grow);
                el.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.7, 0, TimeSpan.FromSeconds(2.4)) { RepeatBehavior = RepeatBehavior.Forever, BeginTime = TimeSpan.FromSeconds(0.8 * i) });
            }
        }

        void ShowCall(string name, string status, string mode)
        {
            F<TextBlock>("CallName").Text = name;
            F<TextBlock>("CallInitial").Text = string.IsNullOrEmpty(name) ? "?" : name.Substring(0, 1).ToUpper();
            F<TextBlock>("CallStatus").Text = status;
            F<StackPanel>("CallOutBtns").Visibility = mode == "out" ? Visibility.Visible : Visibility.Collapsed;
            F<StackPanel>("CallInBtns").Visibility = mode == "in" ? Visibility.Visible : Visibility.Collapsed;
            F<StackPanel>("CallActBtns").Visibility = mode == "act" ? Visibility.Visible : Visibility.Collapsed;
            var cs = F<Grid>("CallScreen");
            if (cs.Visibility != Visibility.Visible)
            {
                cs.Visibility = Visibility.Visible;
                var blur = new BlurEffect { Radius = 30 };
                cs.Effect = blur;
                var ba = new DoubleAnimation(30, 0, TimeSpan.FromMilliseconds(600)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
                ba.Completed += (s, e) => cs.Effect = null;
                blur.BeginAnimation(BlurEffect.RadiusProperty, ba);
                cs.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(420)));
            }
        }

        void HideCall()
        {
            var cs = F<Grid>("CallScreen");
            var a = new DoubleAnimation(0, TimeSpan.FromMilliseconds(380));
            a.Completed += (s, e) => { if (sess == null) cs.Visibility = Visibility.Collapsed; };
            cs.BeginAnimation(UIElement.OpacityProperty, a);
        }

        void WireSession(CallSession s)
        {
            s.OnAccepted = () => Ui(() => { if (sess == s) StartActive(); });
            s.OnDeclined = () => Ui(() => { if (sess == s) EndCall("Chamada recusada"); });
            s.OnEnded = () => Ui(() => { if (sess == s) EndCall(active ? "Ligação encerrada" : "Sem resposta"); });
            s.OnAudio = b => { var v = voice; if (v != null) v.Play(b); };
        }

        void Dial(Contact c)
        {
            if (sess != null) { Toast("Você já está em uma ligação"); return; }
            int id = ++callId;
            active = false; muted = false;
            ShowCall(c.Name, "Chamando…", "out");
            string addr = c.Addr, nick = Nick();
            ThreadPool.QueueUserWorkItem(delegate
            {
                CallSession s;
                try { s = CallSession.Dial(addr, nick, Port); }
                catch (Exception ex) { Ui(() => { if (id == callId && sess == null) { EndCall("Não foi possível ligar: " + ex.Message); } }); return; }
                bool cancelled = false;
                var done = new ManualResetEvent(false);
                Ui(() =>
                {
                    if (id != callId) cancelled = true; else { sess = s; WireSession(s); }
                    done.Set();
                });
                done.WaitOne();
                if (cancelled) { s.End(); return; }
                s.RunCaller();
            });
        }

        void IncomingCall(string ip, int port, CallSession s)
        {
            if (sess != null) { s.Decline(); return; }
            var c = Ensure(ip, port, s.PeerName, true);
            c.LastSeen = DateTime.Now;
            ++callId;
            active = false; muted = false;
            sess = s;
            WireSession(s);
            ShowCall(c.Name, "Ligação recebida", "in");
            Notify("Ligação de " + c.Name);
            ringTimer.Start();
            try { System.Media.SystemSounds.Exclamation.Play(); } catch { }
        }

        void AcceptCall()
        {
            if (sess == null) return;
            ringTimer.Stop();
            sess.Accept();
            StartActive();
        }

        void StartActive()
        {
            ringTimer.Stop();
            active = true;
            callStart = DateTime.Now;
            ShowCall(F<TextBlock>("CallName").Text, "0:00", "act");
            F<Button>("BtnMute").Background = new SolidColorBrush(Color.FromArgb(0x20, 255, 255, 255));
            F<System.Windows.Shapes.Path>("MuteIcon").Fill = Brushes.White;
            F<TextBlock>("MuteLabel").Text = "Mudo";
            if (voice != null) voice.Stop();
            voice = new Voice();
            voice.OnCapture = b => { var s = sess; if (!muted && s != null) s.SendAudio(b); };
            if (!voice.Start()) Toast("Microfone não encontrado: você só vai ouvir");
            callTimer.Start();
            if (mp != null && playing) { mp.Pause(); playing = false; UpdateIcon(); }
        }

        void EndCall(string msg)
        {
            ++callId;
            ringTimer.Stop();
            callTimer.Stop();
            var s = sess;
            sess = null;
            if (voice != null) { var v = voice; voice = null; ThreadPool.QueueUserWorkItem(delegate { v.Stop(); }); }
            if (s != null) s.End();
            bool was = active;
            active = false;
            if (msg == null) { HideCall(); return; }
            F<TextBlock>("CallStatus").Text = msg;
            F<StackPanel>("CallOutBtns").Visibility = Visibility.Collapsed;
            F<StackPanel>("CallInBtns").Visibility = Visibility.Collapsed;
            F<StackPanel>("CallActBtns").Visibility = Visibility.Collapsed;
            var t = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(1300) };
            t.Tick += delegate { t.Stop(); if (sess == null) HideCall(); };
            t.Start();
        }

        static string LocalIp()
        {
            try
            {
                foreach (var a in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
                    if (a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && !IPAddress.IsLoopback(a)) return a.ToString();
            }
            catch { }
            return "127.0.0.1";
        }
    }

    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            try { System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072 | (System.Net.SecurityProtocolType)768; } catch { }
            if (args.Length > 0 && args[0] == "--uninstall")
            {
                if (MessageBox.Show("Remover o capimm-rust deste PC?\nSuas músicas em Músicas\\capimm-rust não serão apagadas.", "Desinstalar capimm-rust",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
                Setup.Remove();
                MessageBox.Show("capimm-rust removido. Até a próxima!", "capimm-rust", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            bool created;
            var mutex = new Mutex(true, "capimm-rust.SingleInstance", out created);
            if (!created) return;
            if (Setup.Get("perf", "0") == "2") { try { Timeline.DesiredFrameRateProperty.OverrideMetadata(typeof(Timeline), new FrameworkPropertyMetadata { DefaultValue = 30 }); } catch { } }
            var app = new Application();
            app.ShutdownMode = ShutdownMode.OnMainWindowClose;
            app.DispatcherUnhandledException += (s, e) => { Util.Log(e.Exception); e.Handled = true; };
            var win = new MainWin();
            win.Build();
            app.Run(win.W);
            GC.KeepAlive(mutex);
        }
    }
}
