@echo off
set "OUT=%~1"
set "SRC=%~dp0"
set "FW=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%FW%\csc.exe" set "FW=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"
taskkill /f /im capimm-rust.exe >nul 2>&1
"%FW%\csc.exe" /nologo /codepage:65001 /target:winexe /optimize+ /win32icon:"%SRC%app.ico" /out:"%OUT%\capimm-rust.exe" /lib:"%FW%\WPF" /r:System.dll /r:System.Core.dll /r:System.Xaml.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Web.Extensions.dll /r:WindowsBase.dll /r:PresentationCore.dll /r:PresentationFramework.dll /r:Microsoft.CSharp.dll /resource:"%SRC%Ui.xaml",Ui.xaml /resource:"%SRC%Island.xaml",Island.xaml /resource:"%SRC%logo.png",logo.png /resource:"%SRC%app.ico",app.ico "%SRC%Net.cs" "%SRC%Extras.cs" "%SRC%Social.cs" "%SRC%Social2.cs" "%SRC%Features.cs" "%SRC%App.cs" > "%OUT%\error.txt" 2>&1
if errorlevel 1 (
  echo fail> "%OUT%\fail.txt"
  exit /b 1
)
copy /y "%SRC%version.txt" "%OUT%\version.txt" >nul
echo ok> "%OUT%\done.txt"
