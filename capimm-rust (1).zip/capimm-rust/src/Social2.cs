using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Microsoft.Win32;

namespace Pulse
{
    // CM-R (biblioteca dos PCs de todos), playlists, importação e servidores com canais
    partial class MainWin
    {
        List<Item> cmrAll = new List<Item>();
        List<string> knownPeers = new List<string>();
        readonly object peerLock = new object();
        List<string> peerSnap = new List<string>();
        bool cmrBusy;
        DateTime cmrLast = DateTime.MinValue;
        Playlist curPl;
        Item pickItem;
        Action<string, string> promptOk;
        string pubPath;
        ObservableCollection<SMsg> sMsgs = new ObservableCollection<SMsg>();
        SrvInfo curSrv;
        ChanInfo curChan;
        GuildClient gc;
        bool srvOwner;

        void BuildSocial()
        {
            Store.Init();
            foreach (var a in Setup.Get("Peers", "").Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)) knownPeers.Add(a);
            server.Peers = () => { lock (peerLock) return new List<string>(peerSnap); };
            BuildDialogs();
            BuildCmr();
            BuildPlaylists();
            BuildServers();
            foreach (var n in new[] { "LocalRes", "OnlineRes", "LibList", "PlItems", "CmrList" }) HookRowButtons(F<ListBox>(n));
            var t = new DispatcherTimer { Interval = TimeSpan.FromSeconds(20) };
            t.Tick += delegate { UpdatePeerSnap(); };
            t.Start();
            UpdatePeerSnap();
        }

        void UpdatePeerSnap()
        {
            var l = new List<string>();
            foreach (var c in contacts) if (!l.Contains(c.Addr)) l.Add(c.Addr);
            foreach (var a in knownPeers) if (!l.Contains(a)) l.Add(a);
            lock (peerLock) peerSnap = l;
        }

        // ---------------- janelas de diálogo (aparecem com mola)
        void ShowDlg(string dlg, string card)
        {
            var g = F<Grid>(dlg);
            var c = F<Border>(card);
            g.Visibility = Visibility.Visible;
            g.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(220)));
            var sc = (ScaleTransform)c.RenderTransform;
            var a = new DoubleAnimation(0.9, 1, TimeSpan.FromMilliseconds(460)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.6 } };
            sc.BeginAnimation(ScaleTransform.ScaleXProperty, a);
            sc.BeginAnimation(ScaleTransform.ScaleYProperty, a);
        }

        void HideDlg(string dlg)
        {
            var g = F<Grid>(dlg);
            var a = new DoubleAnimation(0, TimeSpan.FromMilliseconds(200));
            a.Completed += (s, e) => { if (g.Opacity == 0) g.Visibility = Visibility.Collapsed; };
            g.BeginAnimation(UIElement.OpacityProperty, a);
        }

        void ShowPrompt(string title, string hint, bool typeRow, string initial, Action<string, string> ok)
        {
            promptOk = ok;
            F<TextBlock>("PromptTitle").Text = title;
            F<TextBlock>("PromptHint").Text = hint;
            var box = F<TextBox>("PromptBox");
            box.Text = initial ?? "";
            F<Border>("PromptTypeRow").Visibility = typeRow ? Visibility.Visible : Visibility.Collapsed;
            F<RadioButton>("PromptT1").IsChecked = true;
            ShowDlg("PromptDlg", "PromptCard");
            box.Focus();
            box.SelectAll();
        }

        void PromptDone()
        {
            var ok = promptOk;
            promptOk = null;
            string t = F<TextBox>("PromptBox").Text.Trim();
            string type = F<RadioButton>("PromptT2").IsChecked == true ? "aviso" : "chat";
            HideDlg("PromptDlg");
            if (ok != null && t.Length > 0) ok(t, type);
        }

        void BuildDialogs()
        {
            F<Button>("PromptCancel").Click += delegate { HideDlg("PromptDlg"); };
            F<Button>("PromptOk").Click += delegate { PromptDone(); };
            F<TextBox>("PromptBox").KeyDown += (s, e) => { if (e.Key == Key.Enter) PromptDone(); };
            F<Button>("PubCancel").Click += delegate { HideDlg("PublishDlg"); };
            F<Button>("PubOk").Click += delegate { DoPublish(); };
            F<Button>("PubLoadLyrics").Click += delegate
            {
                var dlg = new OpenFileDialog { Title = "Escolha o arquivo da letra", Filter = "Letras|*.lrc;*.txt|Todos os arquivos|*.*" };
                if (dlg.ShowDialog(W) == true)
                {
                    try { F<TextBox>("PubLyrics").Text = File.ReadAllText(dlg.FileName, Encoding.UTF8); }
                    catch (Exception ex) { Util.Log(ex); Toast("Não consegui ler o arquivo"); }
                }
            };
            F<Button>("PickCancel").Click += delegate { HideDlg("PickDlg"); };
            F<Button>("PickNew").Click += delegate
            {
                var it = pickItem;
                HideDlg("PickDlg");
                ShowPrompt("Nova playlist", "Dê um nome para a sua playlist.", false, "", (t, ty) => { var p = NewPlaylist(t); if (it != null) AddEntry(p, it); });
            };
            F<ListBox>("PickList").SelectionChanged += delegate
            {
                var lb = F<ListBox>("PickList");
                var p = lb.SelectedItem as Playlist;
                if (p == null) return;
                lb.SelectedItem = null;
                if (pickItem != null) AddEntry(p, pickItem);
                HideDlg("PickDlg");
            };
            F<Button>("ImpOpen").Click += delegate
            {
                var dlg = new OpenFileDialog { Title = "Escolha o arquivo da playlist", Filter = "Playlists|*.csv;*.txt;*.json;*.m3u;*.m3u8|Todos os arquivos|*.*" };
                if (dlg.ShowDialog(W) == true)
                {
                    try
                    {
                        F<TextBox>("ImpText").Text = File.ReadAllText(dlg.FileName, Encoding.UTF8);
                        if (F<TextBox>("ImpName").Text.Trim().Length == 0) F<TextBox>("ImpName").Text = System.IO.Path.GetFileNameWithoutExtension(dlg.FileName);
                    }
                    catch (Exception ex) { Util.Log(ex); Toast("Não consegui ler o arquivo"); }
                }
            };
            F<Button>("ImpCancel").Click += delegate { HideDlg("ImportDlg"); };
            F<Button>("ImpGo").Click += delegate
            {
                string name = F<TextBox>("ImpName").Text.Trim();
                if (name.Length == 0) name = "Importada";
                string text = F<TextBox>("ImpText").Text;
                if (text.Trim().Length == 0) { Toast("Cole uma lista ou abra um arquivo"); return; }
                HideDlg("ImportDlg");
                RunImport(name, text);
            };
            W.PreviewKeyDown += (s, e) =>
            {
                if (e.Key != Key.Escape) return;
                foreach (var d in new[] { "PromptDlg", "PublishDlg", "ImportDlg", "PickDlg" })
                {
                    var g = F<Grid>(d);
                    if (g.Visibility == Visibility.Visible && g.Opacity > 0.5) { HideDlg(d); e.Handled = true; return; }
                }
            };
        }

        void HookRowButtons(ListBox lb)
        {
            lb.AddHandler(Button.ClickEvent, new RoutedEventHandler((s, e) =>
            {
                var b = e.OriginalSource as Button;
                if (b == null) return;
                var it = b.DataContext as Item;
                if (it == null) return;
                string tag = b.Tag as string;
                if (tag == "add") AddToPlaylist(it);
                else if (tag == "dl") DownloadItem(it);
            }));
        }

        // ---------------- tocar / baixar músicas remotas (com plano B para links que dão 404)
        static string Sanitize(string s)
        {
            var sb = new StringBuilder();
            foreach (char c in s ?? "")
                sb.Append(Array.IndexOf(System.IO.Path.GetInvalidFileNameChars(), c) >= 0 ? ' ' : c);
            string r = sb.ToString().Trim();
            return r.Length == 0 ? "musica" : (r.Length > 120 ? r.Substring(0, 120) : r);
        }

        static void FetchAny(List<string> urls, string dest)
        {
            string last = "sem endereço";
            foreach (var u in urls)
            {
                if (string.IsNullOrEmpty(u)) continue;
                try
                {
                    using (var wc = new System.Net.WebClient())
                    {
                        wc.Headers["User-Agent"] = "capimm-rust/4.0";
                        wc.DownloadFile(u, dest);
                    }
                    if (File.Exists(dest) && new FileInfo(dest).Length > 2048) return;
                    last = "arquivo vazio";
                }
                catch (Exception ex) { last = ex.Message; Util.Log(ex); }
                try { if (File.Exists(dest)) File.Delete(dest); } catch { }
            }
            throw new Exception(last);
        }

        void PlayRemote(Item it, int id)
        {
            if (it.PubId == null && string.IsNullOrEmpty(it.Url)) { Toast("Esta faixa não foi encontrada em nenhuma fonte"); return; }
            Toast(it.PubId != null ? "Conectando à CM-R…" : (it.Full ? "Carregando a música completa…" : "Carregando prévia…"));
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    string dir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "capimm-rust");
                    Directory.CreateDirectory(dir);
                    string key = it.PubId != null ? (it.Addr + it.PubId) : it.Url;
                    string ext = (it.PubId != null && !string.IsNullOrEmpty(it.Ext)) ? it.Ext : ".mp3";
                    string tmp = System.IO.Path.Combine(dir, "t" + ((uint)key.GetHashCode()).ToString("x8") + ext);
                    if (!File.Exists(tmp) || new FileInfo(tmp).Length < 1024)
                    {
                        if (it.PubId != null) Cmr.Download(it.Addr, it.PubId, tmp);
                        else
                        {
                            var urls = new List<string> { it.Url };
                            if (it.Alts != null) urls.AddRange(it.Alts);
                            FetchAny(urls, tmp);
                        }
                    }
                    Ui(() => { if (id == playId) StartMedia(tmp); });
                }
                catch (Exception ex)
                {
                    Util.Log(ex);
                    Ui(() => { if (id == playId) Toast("Não consegui carregar: " + ex.Message); });
                }
            });
        }

        void DownloadItem(Item it)
        {
            if (it.Path != null) { Toast("Já está na sua biblioteca"); return; }
            if (it.Source != "CM-R" && it.Source != "Jamendo") { Toast("Só músicas da CM-R e do Jamendo podem ser baixadas para ouvir offline"); return; }
            string baseName = Sanitize((string.IsNullOrEmpty(it.Artist) ? "" : it.Artist + " - ") + it.Name);
            string ext = string.IsNullOrEmpty(it.Ext) ? ".mp3" : it.Ext;
            string dest = System.IO.Path.Combine(Util.LibDir, baseName + ext);
            if (File.Exists(dest)) { Toast("Já baixada"); return; }
            Toast("Baixando " + it.Name + "…");
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    if (it.PubId != null)
                    {
                        Cmr.Download(it.Addr, it.PubId, dest);
                        string lyr = null;
                        try { lyr = Cmr.Lyrics(it.Addr, it.PubId); } catch { }
                        if (!string.IsNullOrEmpty(lyr))
                        {
                            string le = Extra.ParseLrc(lyr).Count > 0 ? ".lrc" : ".txt";
                            File.WriteAllText(System.IO.Path.ChangeExtension(dest, le), lyr, new UTF8Encoding(false));
                        }
                    }
                    else
                    {
                        var urls = new List<string>();
                        if (!string.IsNullOrEmpty(it.Url)) urls.Add(it.Url);
                        if (it.Alts != null) urls.AddRange(it.Alts);
                        FetchAny(urls, dest);
                    }
                    Ui(() => { ReloadLib(); Toast("Baixada: " + it.Name + " (disponível offline)"); });
                }
                catch (Exception ex)
                {
                    Util.Log(ex);
                    try { if (File.Exists(dest)) File.Delete(dest); } catch { }
                    Ui(() => Toast("Falha ao baixar: " + ex.Message));
                }
            });
        }

        static string OwnLyrics(Item it)
        {
            if (it.PubId != null)
            {
                if (it.Path != null) { var pb = Store.FindPub(it.PubId); if (pb != null) return pb.Lyrics; }
                else if (it.Addr != null) return Cmr.Lyrics(it.Addr, it.PubId);
            }
            if (it.Path != null)
            {
                foreach (string ext in new[] { ".lrc", ".txt" })
                {
                    string p = System.IO.Path.ChangeExtension(it.Path, ext);
                    if (File.Exists(p)) return File.ReadAllText(p, Encoding.UTF8);
                }
            }
            return null;
        }

        // ---------------- CM-R
        void BuildCmr()
        {
            ClickPlay(F<ListBox>("CmrList"));
            F<TextBox>("CmrSearch").TextChanged += delegate { ApplyCmrFilter(); };
            F<Button>("BtnCmrRefresh").Click += delegate { RefreshCmr(); };
            F<Button>("BtnPublish").Click += delegate { OpenPublish(); };
            F<Button>("BtnUnpub").Click += delegate { Unpublish(); };
            RefreshMyPubs();
            var t = new DispatcherTimer { Interval = TimeSpan.FromSeconds(90) };
            t.Tick += delegate { if (curPage == 2 && W.IsActive) RefreshCmr(); };
            t.Start();
        }

        Item PubToItem(Pub p, string addr, bool mine)
        {
            var it = new Item
            {
                Name = p.Title, Artist = p.Artist, Source = "CM-R", Full = true, Addr = addr, PubId = p.Id, Owner = p.Owner,
                Ext = System.IO.Path.GetExtension(p.File ?? ""),
                Tag = mine ? "CM-R · você" : "CM-R · " + p.Owner
            };
            if (mine) it.Path = System.IO.Path.Combine(Util.LibDir, p.File ?? "");
            return it;
        }

        void RefreshMyPubs()
        {
            var l = new List<Item>();
            foreach (var p in Store.PubsSnapshot()) l.Add(PubToItem(p, "127.0.0.1:" + Port, true));
            var lb = F<ListBox>("MyPubList");
            lb.ItemsSource = null;
            lb.ItemsSource = l;
        }

        void RefreshCmr()
        {
            if (cmrBusy) return;
            cmrBusy = true;
            cmrLast = DateTime.Now;
            F<TextBlock>("CmrStatus").Text = "Procurando pessoas na rede…";
            var peers = new List<string>();
            foreach (var c in contacts) if (!peers.Contains(c.Addr)) peers.Add(c.Addr);
            foreach (var a in knownPeers) if (!peers.Contains(a)) peers.Add(a);
            string myAddr = LocalIp() + ":" + Port;
            peers.Remove(myAddr);
            var mine = new List<Item>();
            foreach (var p in Store.PubsSnapshot()) mine.Add(PubToItem(p, "127.0.0.1:" + Port, true));
            ThreadPool.QueueUserWorkItem(delegate
            {
                var items = new List<Item>(mine);
                var newPeers = new List<string>();
                int online = 0;
                var lk = new object();
                var th = new List<Thread>();
                foreach (var pa in peers)
                {
                    if (th.Count >= 40) break;
                    string addr = pa;
                    var t = new Thread(() =>
                    {
                        try
                        {
                            var r = Cmr.Catalog(addr);
                            List<string> np = null;
                            try { np = Cmr.Peers(addr); } catch { }
                            lock (lk) { items.AddRange(r); online++; if (np != null) newPeers.AddRange(np); }
                        }
                        catch { }
                    });
                    t.IsBackground = true;
                    t.Start();
                    th.Add(t);
                }
                foreach (var t2 in th) t2.Join(9000);
                List<Item> snap; int on; List<string> npl;
                lock (lk) { snap = new List<Item>(items); on = online; npl = new List<string>(newPeers); }
                Ui(() =>
                {
                    cmrBusy = false;
                    var seen = new HashSet<string>();
                    var all = new List<Item>();
                    foreach (var i in snap) if (seen.Add(i.Addr + "|" + i.PubId)) all.Add(i);
                    all.Sort((x, y) => string.Compare(x.Name, y.Name, StringComparison.CurrentCultureIgnoreCase));
                    cmrAll = all;
                    foreach (var np in npl)
                    {
                        string pr = Util.ParseCode(np);
                        if (pr == null || pr == myAddr || pr.StartsWith("127.")) continue;
                        if (!knownPeers.Contains(pr) && knownPeers.Count < 150) knownPeers.Add(pr);
                    }
                    Setup.Set("Peers", string.Join(";", knownPeers.ToArray()));
                    UpdatePeerSnap();
                    ApplyCmrFilter();
                    int people = on + 1;
                    F<TextBlock>("CmrStatus").Text = people + (people == 1 ? " pessoa" : " pessoas") + " online · " + cmrAll.Count + (cmrAll.Count == 1 ? " música" : " músicas");
                });
            });
        }

        void ApplyCmrFilter()
        {
            string q = F<TextBox>("CmrSearch").Text.Trim();
            var l = new List<Item>();
            foreach (var i in cmrAll)
            {
                if (q.Length == 0
                    || i.Name.IndexOf(q, StringComparison.CurrentCultureIgnoreCase) >= 0
                    || (i.Artist ?? "").IndexOf(q, StringComparison.CurrentCultureIgnoreCase) >= 0
                    || (i.Owner ?? "").IndexOf(q, StringComparison.CurrentCultureIgnoreCase) >= 0) l.Add(i);
            }
            SetItems(F<ListBox>("CmrList"), l);
            F<TextBlock>("CmrEmpty").Visibility = l.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        void OpenPublish()
        {
            var dlg = new OpenFileDialog { Title = "Escolha a música para publicar", Filter = "Músicas|*.mp3;*.flac;*.wav;*.ogg;*.m4a;*.aac;*.wma" };
            if (dlg.ShowDialog(W) != true) return;
            string name = System.IO.Path.GetFileName(dlg.FileName);
            string dest = System.IO.Path.Combine(Util.LibDir, name);
            try { if (!File.Exists(dest)) File.Copy(dlg.FileName, dest); }
            catch (Exception ex) { Util.Log(ex); Toast("Não consegui copiar o arquivo"); return; }
            pubPath = dest;
            string t = System.IO.Path.GetFileNameWithoutExtension(name), a = "";
            int k = t.IndexOf(" - ");
            if (k > 0) { a = t.Substring(0, k).Trim(); t = t.Substring(k + 3).Trim(); }
            F<TextBox>("PubTitle").Text = t;
            F<TextBox>("PubArtist").Text = a;
            F<TextBox>("PubLyrics").Text = "";
            F<CheckBox>("PubRights").IsChecked = false;
            F<TextBlock>("PubFile").Text = name;
            ShowDlg("PublishDlg", "PublishCard");
            ReloadLib();
        }

        void DoPublish()
        {
            if (F<CheckBox>("PubRights").IsChecked != true) { Toast("Confirme que você tem os direitos desta música"); return; }
            string title = F<TextBox>("PubTitle").Text.Trim();
            if (title.Length == 0) { Toast("Dê um título para a música"); return; }
            if (pubPath == null || !File.Exists(pubPath)) { Toast("Arquivo não encontrado"); return; }
            var pb = new Pub
            {
                Id = GuildHost.NewId(), Title = title, Artist = F<TextBox>("PubArtist").Text.Trim(),
                File = System.IO.Path.GetFileName(pubPath), Lyrics = F<TextBox>("PubLyrics").Text,
                Owner = Nick(), Size = new FileInfo(pubPath).Length, Added = DateTime.UtcNow.Ticks
            };
            Store.AddPub(pb);
            HideDlg("PublishDlg");
            RefreshMyPubs();
            RefreshCmr();
            Toast("Publicada na CM-R! Quem estiver na rede já pode ouvir.");
        }

        void Unpublish()
        {
            var it = F<ListBox>("MyPubList").SelectedItem as Item;
            if (it == null) { Toast("Selecione uma publicação"); return; }
            Store.RemovePub(it.PubId);
            RefreshMyPubs();
            RefreshCmr();
            Toast("Publicação removida da CM-R");
        }

        // ---------------- playlists
        static PlEntry FromItem(Item i)
        {
            return new PlEntry { Name = i.Name, Artist = i.Artist, Path = i.Path, Url = i.Url, Cover = i.Cover, CoverBig = i.CoverBig, Source = i.Source, Full = i.Full, Addr = i.Addr, PubId = i.PubId, Ext = i.Ext, Alts = i.Alts, Found = true };
        }

        static Item ToItem(PlEntry e)
        {
            var it = new Item { Name = e.Name, Artist = e.Artist, Path = e.Path, Url = e.Url, Cover = e.Cover, CoverBig = e.CoverBig, Source = e.Source, Full = e.Full, Addr = e.Addr, PubId = e.PubId, Ext = e.Ext, Alts = e.Alts };
            it.Tag = !e.Found ? "não encontrada" : (e.Source == "CM-R" ? "CM-R" : (e.Full ? "completa" : "prévia 30 s"));
            return it;
        }

        List<Item> ToItems(Playlist p)
        {
            var l = new List<Item>();
            foreach (var e in p.Items) l.Add(ToItem(e));
            return l;
        }

        void BuildPlaylists()
        {
            F<RadioButton>("LibTabM").Checked += delegate { ShowLibTab(false); };
            F<RadioButton>("LibTabP").Checked += delegate { ShowLibTab(true); };
            var names = F<ListBox>("PlNames");
            names.SelectionChanged += delegate { var p = names.SelectedItem as Playlist; if (p != null) ShowPlaylist(p); };
            ClickPlay(F<ListBox>("PlItems"));
            F<Button>("BtnNewPl").Click += delegate { ShowPrompt("Nova playlist", "Dê um nome para a sua playlist.", false, "", (t, ty) => NewPlaylist(t)); };
            F<Button>("BtnImpPl").Click += delegate
            {
                F<TextBox>("ImpName").Text = "";
                F<TextBox>("ImpText").Text = "";
                ShowDlg("ImportDlg", "ImportCard");
            };
            F<Button>("BtnPlPlay").Click += delegate
            {
                if (curPl == null) return;
                var l = ToItems(curPl);
                int i = l.FindIndex(x => x.Path != null || x.Url != null || x.PubId != null);
                if (i >= 0) PlayFrom(l, i); else Toast("Nenhuma música tocável nesta playlist");
            };
            F<Button>("BtnPlDelete").Click += delegate
            {
                if (curPl == null) return;
                Store.Playlists.Remove(curPl);
                Store.SavePlaylists();
                curPl = null;
                F<TextBlock>("PlTitle").Text = "Escolha uma playlist";
                F<ListBox>("PlItems").ItemsSource = null;
                RefreshPlaylists();
            };
            F<ListBox>("PlItems").KeyDown += (s, e) =>
            {
                if (e.Key != Key.Delete || curPl == null) return;
                int idx = F<ListBox>("PlItems").SelectedIndex;
                if (idx >= 0 && idx < curPl.Items.Count)
                {
                    curPl.Items.RemoveAt(idx);
                    Store.SavePlaylists();
                    ShowPlaylist(curPl);
                    RefreshPlaylists();
                }
            };
        }

        void ShowLibTab(bool pl)
        {
            F<ListBox>("LibList").Visibility = pl ? Visibility.Collapsed : Visibility.Visible;
            F<TextBlock>("LibEmpty").Visibility = (!pl && lib.Count == 0) ? Visibility.Visible : Visibility.Collapsed;
            F<Grid>("LibPl").Visibility = pl ? Visibility.Visible : Visibility.Collapsed;
            if (pl) RefreshPlaylists();
        }

        void RefreshPlaylists()
        {
            var lb = F<ListBox>("PlNames");
            var keep = curPl;
            lb.ItemsSource = null;
            lb.ItemsSource = Store.Playlists;
            if (keep != null && Store.Playlists.Contains(keep)) lb.SelectedItem = keep;
        }

        void ShowPlaylist(Playlist p)
        {
            curPl = p;
            F<TextBlock>("PlTitle").Text = p.Name;
            SetItems(F<ListBox>("PlItems"), ToItems(p));
        }

        Playlist NewPlaylist(string name)
        {
            var p = new Playlist { Name = name };
            Store.Playlists.Add(p);
            Store.SavePlaylists();
            RefreshPlaylists();
            return p;
        }

        void AddEntry(Playlist p, Item it)
        {
            p.Items.Add(FromItem(it));
            Store.SavePlaylists();
            Toast("Adicionada a " + p.Name);
            RefreshPlaylists();
        }

        void AddToPlaylist(Item it)
        {
            pickItem = it;
            var lb = F<ListBox>("PickList");
            lb.ItemsSource = null;
            lb.ItemsSource = Store.Playlists;
            ShowDlg("PickDlg", "PickCard");
        }

        // ---------------- importar playlist do Spotify, YouTube Music e outros (por lista/CSV/JSON)
        static string Norm(string s)
        {
            var sb = new StringBuilder();
            foreach (char c in (s ?? "").ToLowerInvariant()) if (char.IsLetterOrDigit(c)) sb.Append(c);
            return sb.ToString();
        }

        static string Dstr(Dictionary<string, object> d, string k)
        {
            object v;
            return d.TryGetValue(k, out v) && v != null ? v.ToString() : "";
        }

        static List<string> CsvLine(string line)
        {
            var r = new List<string>();
            var sb = new StringBuilder();
            bool q = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (q)
                {
                    if (c == '"') { if (i + 1 < line.Length && line[i + 1] == '"') { sb.Append('"'); i++; } else q = false; }
                    else sb.Append(c);
                }
                else if (c == '"') q = true;
                else if (c == ',') { r.Add(sb.ToString()); sb.Length = 0; }
                else sb.Append(c);
            }
            r.Add(sb.ToString());
            return r;
        }

        static void CollectTracks(object o, List<string[]> acc)
        {
            var d = o as Dictionary<string, object>;
            if (d != null)
            {
                string tn = Dstr(d, "trackName"), an = Dstr(d, "artistName");
                if (tn.Length > 0 && an.Length > 0) { acc.Add(new[] { an, tn }); return; }
                string n2 = Dstr(d, "name");
                object av;
                var arts = d.TryGetValue("artists", out av) ? av as System.Collections.IEnumerable : null;
                if (n2.Length > 0 && arts != null)
                {
                    string a1 = "";
                    foreach (object ao in arts) { var ad = ao as Dictionary<string, object>; if (ad != null) { a1 = Dstr(ad, "name"); break; } }
                    acc.Add(new[] { a1, n2 });
                    return;
                }
                foreach (var v in d.Values) CollectTracks(v, acc);
                return;
            }
            var arr = o as System.Collections.IEnumerable;
            if (arr != null && !(o is string)) foreach (object x in arr) CollectTracks(x, acc);
        }

        static List<string[]> ParseImport(string text)
        {
            var res = new List<string[]>();
            string t = text.Trim();
            if (t.StartsWith("{") || t.StartsWith("["))
            {
                try { CollectTracks(new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.DeserializeObject(t), res); } catch { }
                if (res.Count > 0) return res;
            }
            string[] lines = t.Replace("\r", "").Split('\n');
            if (lines.Length > 1 && lines[0].Contains(","))
            {
                var head = CsvLine(lines[0]);
                int ti = -1, ai = -1;
                for (int i = 0; i < head.Count; i++)
                {
                    string h = head[i].Trim().ToLowerInvariant();
                    if (ti < 0 && (h.StartsWith("track name") || h == "title" || h == "song" || h == "track" || h == "name" || h == "título" || h == "titulo")) ti = i;
                    if (ai < 0 && (h.StartsWith("artist") || h == "artista")) ai = i;
                }
                if (ti >= 0)
                {
                    for (int r = 1; r < lines.Length; r++)
                    {
                        if (lines[r].Trim().Length == 0) continue;
                        var f = CsvLine(lines[r]);
                        if (ti >= f.Count) continue;
                        string ar = (ai >= 0 && ai < f.Count) ? f[ai] : "";
                        int sc = ar.IndexOf(';');
                        if (sc > 0) ar = ar.Substring(0, sc);
                        res.Add(new[] { ar.Trim(), f[ti].Trim() });
                    }
                    if (res.Count > 0) return res;
                }
            }
            foreach (string raw in lines)
            {
                string l = raw.Trim();
                if (l.Length == 0 || l.StartsWith("#EXTM3U")) continue;
                if (l.StartsWith("#EXTINF:")) { int k = l.IndexOf(','); if (k >= 0) l = l.Substring(k + 1).Trim(); else continue; }
                else if (l.StartsWith("#")) continue;
                if (l.StartsWith("http", StringComparison.OrdinalIgnoreCase)) continue;
                string artist = "", title = l;
                int d = l.IndexOf(" - ");
                if (d > 0) { artist = l.Substring(0, d).Trim(); title = l.Substring(d + 3).Trim(); }
                res.Add(new[] { artist, title });
            }
            return res;
        }

        static PlEntry MatchEntry(string ar, string ti, List<Item> libCopy, List<Item> cmrCopy, bool ja, bool au, bool dz, string jkey)
        {
            string nt = Norm(ti), na = Norm(ar);
            if (nt.Length == 0) return null;
            foreach (var i in libCopy)
                if (Norm(i.Name).Contains(nt) && (na.Length == 0 || Norm(i.Name + i.Artist).Contains(na))) return FromItem(i);
            foreach (var i in cmrCopy)
                if (Norm(i.Name).Contains(nt) && (na.Length == 0 || Norm(i.Name + i.Artist).Contains(na))) return FromItem(i);
            if (ja)
            {
                try { foreach (var i in Extra.Jamendo(ti, jkey)) if (Norm(i.Name).Contains(nt)) return FromItem(i); } catch { }
            }
            if (au)
            {
                try { foreach (var i in Extra.Audius((ti + " " + ar).Trim())) if (Norm(i.Name).Contains(nt)) return FromItem(i); } catch { }
            }
            if (dz)
            {
                try { foreach (var i in Web.Search((ti + " " + ar).Trim())) if (Norm(i.Name).Contains(nt)) return FromItem(i); } catch { }
            }
            return null;
        }

        void RunImport(string name, string text)
        {
            var entries = ParseImport(text);
            if (entries.Count == 0) { Toast("Não encontrei músicas na lista"); return; }
            if (entries.Count > 300) entries = entries.GetRange(0, 300);
            bool ja = Cfg("jamendo", true), au = Cfg("audius", true), dz = Cfg("deezer", true);
            string jkey = Setup.Get("jamkey", "");
            if (jkey.Length == 0) jkey = Extra.JamKey;
            var libCopy = new List<Item>(lib);
            var cmrCopy = new List<Item>(cmrAll);
            int total = entries.Count;
            Toast("Importando " + total + " músicas… isso pode levar um tempo");
            ThreadPool.QueueUserWorkItem(delegate
            {
                var pl = new Playlist { Name = name };
                int found = 0, k = 0;
                foreach (var en in entries)
                {
                    k++;
                    PlEntry hit = null;
                    try { hit = MatchEntry(en[0], en[1], libCopy, cmrCopy, ja, au, dz, jkey); } catch (Exception ex) { Util.Log(ex); }
                    if (hit != null) { pl.Items.Add(hit); found++; }
                    else pl.Items.Add(new PlEntry { Name = en[1], Artist = en[0], Found = false });
                    if (k % 8 == 0) { int kk = k; Ui(() => Toast("Procurando… " + kk + " de " + total)); }
                }
                Ui(() =>
                {
                    Store.Playlists.Add(pl);
                    Store.SavePlaylists();
                    curPl = pl;
                    F<RadioButton>("LibTabP").IsChecked = true;
                    RefreshPlaylists();
                    Toast("Playlist \"" + name + "\": " + found + " de " + total + " músicas encontradas");
                });
            });
        }

        // ---------------- servidores (como Discord) com canais de conversa e de avisos (como canais do WhatsApp)
        string InviteFor(SrvInfo s)
        {
            string addr = s.Mine ? LocalIp() + ":" + Port : s.Addr;
            int i = addr.LastIndexOf(':');
            int port;
            int.TryParse(addr.Substring(i + 1), out port);
            return Util.MakeCode(addr.Substring(0, i), port) + "~" + s.Id;
        }

        void BuildServers()
        {
            F<ListBox>("SMsgList").ItemsSource = sMsgs;
            F<Button>("BtnSrvNew").Click += delegate
            {
                ShowPrompt("Criar servidor", "Seu PC vai hospedar o servidor. Ele só fica no ar enquanto o seu PC estiver ligado e o app aberto.", false, "", (t, ty) => CreateServer(t));
            };
            F<Button>("BtnSrvJoin").Click += delegate
            {
                ShowPrompt("Entrar em um servidor", "Cole o convite que o dono te passou.", false, "", (t, ty) => JoinServer(t));
            };
            F<Button>("BtnInvite").Click += delegate
            {
                if (curSrv == null) return;
                try { Clipboard.SetText(InviteFor(curSrv)); Toast("Convite copiado"); } catch { }
            };
            F<Button>("BtnChanNew").Click += delegate
            {
                if (gc == null || !srvOwner) return;
                ShowPrompt("Novo canal", "Escolha o nome e o tipo do canal.", true, "", (t, ty) => { if (gc != null) gc.NewChan(t, ty); });
            };
            F<Button>("BtnSrvLeave").Click += delegate { LeaveServer(); };
            var cl = F<ListBox>("ChanList");
            cl.SelectionChanged += delegate { var c = cl.SelectedItem as ChanInfo; if (c != null) SelectChannel(c); };
            F<TextBox>("SMsgBox").KeyDown += (s, e) => { if (e.Key == Key.Enter) SendS(); };
            F<Button>("BtnSSend").Click += delegate { SendS(); };
            RebuildRail();
        }

        void RebuildRail()
        {
            var rail = F<StackPanel>("SrvRail");
            rail.Children.Clear();
            var all = new List<SrvInfo>();
            all.AddRange(Store.Hosted);
            all.AddRange(Store.Joined);
            foreach (var s in all)
            {
                var srv = s;
                bool sel = curSrv != null && curSrv.Id == srv.Id;
                var b = new Button
                {
                    Style = (Style)W.FindResource(sel ? "BtnWC" : "BtnC"),
                    Width = 52, Height = 52, Margin = new Thickness(0, 0, 0, 10), ToolTip = srv.Name,
                    Content = new TextBlock { Text = srv.Initial, FontSize = 18, FontWeight = FontWeights.SemiBold }
                };
                b.Click += (x, y) => SelectServer(srv);
                rail.Children.Add(b);
            }
        }

        void CreateServer(string name)
        {
            var s = GuildHost.Create(name, Nick());
            RebuildRail();
            SelectServer(s);
            Toast("Servidor criado! Use \"Copiar convite\" para chamar amigos.");
        }

        void JoinServer(string code)
        {
            string[] parts = code.Trim().Split('~');
            string addr = Util.ParseCode(parts[0]);
            if (addr == null || parts.Length < 2 || parts[1].Trim().Length == 0) { Toast("Convite inválido"); return; }
            string id = parts[1].Trim();
            foreach (var s in Store.Hosted) if (s.Id == id) { SelectServer(s); return; }
            foreach (var s in Store.Joined) if (s.Id == id) { SelectServer(s); return; }
            var srv = new SrvInfo { Id = id, Name = "Servidor " + id, Owner = "", Addr = addr, Mine = false };
            Store.Joined.Add(srv);
            Store.SaveJoined();
            RebuildRail();
            SelectServer(srv);
        }

        void LeaveServer()
        {
            if (curSrv == null) return;
            if (gc != null) { gc.Close(); gc = null; }
            if (curSrv.Mine) { Store.Hosted.Remove(curSrv); Store.SaveHosted(); }
            else { Store.Joined.Remove(curSrv); Store.SaveJoined(); }
            curSrv = null; curChan = null; sMsgs.Clear();
            F<TextBlock>("SrvName").Text = "Servidores";
            F<TextBlock>("SrvOwnerNote").Text = "";
            F<TextBlock>("SrvMembers").Text = "";
            F<ListBox>("ChanList").ItemsSource = null;
            F<Button>("BtnInvite").Visibility = Visibility.Collapsed;
            F<Button>("BtnChanNew").Visibility = Visibility.Collapsed;
            F<Button>("BtnSrvLeave").Visibility = Visibility.Collapsed;
            F<Grid>("SChat").Visibility = Visibility.Collapsed;
            F<TextBlock>("SEmpty").Visibility = Visibility.Visible;
            RebuildRail();
        }

        void SelectServer(SrvInfo s)
        {
            if (gc != null) { gc.Close(); gc = null; }
            curSrv = s; curChan = null; srvOwner = false;
            sMsgs.Clear();
            F<TextBlock>("SEmpty").Visibility = Visibility.Collapsed;
            F<Grid>("SChat").Visibility = Visibility.Collapsed;
            F<TextBlock>("SrvName").Text = s.Name;
            F<TextBlock>("SrvOwnerNote").Text = "Conectando…";
            F<TextBlock>("SrvMembers").Text = "";
            F<Button>("BtnInvite").Visibility = Visibility.Visible;
            F<Button>("BtnSrvLeave").Visibility = Visibility.Visible;
            F<Button>("BtnSrvLeave").Content = s.Mine ? "Excluir servidor" : "Sair do servidor";
            F<Button>("BtnChanNew").Visibility = Visibility.Collapsed;
            F<ListBox>("ChanList").ItemsSource = s.Chans;
            RebuildRail();
            var cc = new GuildClient();
            gc = cc;
            cc.OnMeta = (m, owner) => Ui(() => { if (gc == cc) ApplyMeta(m, owner); });
            cc.OnMsg = (m, hist) => Ui(() => { if (gc == cc) AddSMsg(m, hist); });
            cc.OnPres = names => Ui(() => { if (gc == cc) F<TextBlock>("SrvMembers").Text = names.Length == 0 ? "" : "Online agora: " + string.Join(", ", names); });
            cc.OnErr = msg => Ui(() => Toast(msg));
            cc.OnClosed = () => Ui(() => { if (gc == cc) { Toast("Desconectado do servidor"); F<TextBlock>("SrvOwnerNote").Text = "Desconectado"; } });
            string addr = s.Mine ? "127.0.0.1:" + Port : s.Addr;
            string nick = Nick();
            string sid = s.Id;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try { cc.Connect(addr, sid, nick); }
                catch (Exception ex)
                {
                    Util.Log(ex);
                    Ui(() => { if (gc == cc) { Toast("Servidor: " + ex.Message); F<TextBlock>("SrvOwnerNote").Text = "Offline"; } });
                }
            });
        }

        void ApplyMeta(SrvInfo meta, bool owner)
        {
            srvOwner = owner;
            if (curSrv != null)
            {
                curSrv.Name = meta.Name; curSrv.Owner = meta.Owner; curSrv.Chans = meta.Chans;
                if (!curSrv.Mine) Store.SaveJoined();
            }
            F<TextBlock>("SrvName").Text = meta.Name;
            F<TextBlock>("SrvOwnerNote").Text = owner ? "Você é o dono · o servidor só fica no ar com o seu PC ligado" : "Dono: " + meta.Owner;
            F<Button>("BtnChanNew").Visibility = owner ? Visibility.Visible : Visibility.Collapsed;
            var cl = F<ListBox>("ChanList");
            string keep = curChan != null ? curChan.Id : null;
            cl.ItemsSource = null;
            cl.ItemsSource = meta.Chans;
            ChanInfo pick = null;
            foreach (var c in meta.Chans) if (c.Id == keep) pick = c;
            if (pick == null && meta.Chans.Count > 0) pick = meta.Chans[0];
            if (pick != null) cl.SelectedItem = pick;
            RebuildRail();
        }

        void SelectChannel(ChanInfo c)
        {
            if (curChan != null && curChan.Id == c.Id) { curChan = c; return; }
            curChan = c;
            sMsgs.Clear();
            F<TextBlock>("SEmpty").Visibility = Visibility.Collapsed;
            var chat = F<Grid>("SChat");
            if (chat.Visibility != Visibility.Visible) FadeIn(chat);
            F<TextBlock>("ChanTitle").Text = c.Icon + " " + c.Name;
            bool canPost = c.Type != "aviso" || srvOwner;
            F<TextBlock>("ChanKind").Text = c.Type == "aviso"
                ? (srvOwner ? "Canal de avisos · só você publica aqui" : "Canal de avisos · só o dono publica")
                : "Conversa do servidor";
            F<TextBox>("SMsgBox").IsEnabled = canPost;
            F<Button>("BtnSSend").IsEnabled = canPost;
            if (gc != null) gc.Hist(c.Id, 100);
        }

        void AddSMsg(SMsg m, bool hist)
        {
            if (!hist && m.Nick != Nick() && (curPage != 4 || !W.IsActive) && Cfg("notif", true))
                Notify((curSrv != null ? curSrv.Name + " · " : "") + m.Nick + ": " + m.Text);
            if (curChan == null || m.Chan != curChan.Id) return;
            sMsgs.Add(m);
            F<ListBox>("SMsgList").ScrollIntoView(m);
        }

        void SendS()
        {
            var box = F<TextBox>("SMsgBox");
            string t = box.Text.Trim();
            if (t.Length == 0 || gc == null || curChan == null) return;
            gc.Say(curChan.Id, t);
            box.Clear();
        }
    }
}
