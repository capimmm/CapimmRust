using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace Pulse
{
    // ---------------------------------------------------------------- modelos
    public class Pub
    {
        public string Id; public string Title; public string Artist; public string File;
        public string Lyrics; public string Owner; public long Size; public long Added;
    }

    public class PlEntry
    {
        public string Name { get; set; }
        public string Artist { get; set; }
        public string Path { get; set; }
        public string Url { get; set; }
        public string Cover { get; set; }
        public string CoverBig { get; set; }
        public string Source { get; set; }
        public bool Full { get; set; }
        public string Addr { get; set; }
        public string PubId { get; set; }
        public string Ext { get; set; }
        public bool Found { get; set; }
        public List<string> Alts { get; set; }
    }

    public class Playlist
    {
        public string Name { get; set; }
        public List<PlEntry> Items { get; set; }
        public Playlist() { Items = new List<PlEntry>(); }
        [ScriptIgnore]
        public string CountText { get { return Items.Count + (Items.Count == 1 ? " música" : " músicas"); } }
    }

    public class ChanInfo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }   // "chat" (todos falam) ou "aviso" (só o dono posta)
        [ScriptIgnore] public string Icon { get { return Type == "aviso" ? "»" : "#"; } }
        [ScriptIgnore] public string Sub { get { return Type == "aviso" ? "avisos (só o dono posta)" : "conversa"; } }
    }

    public class SrvInfo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Owner { get; set; }
        public string Addr { get; set; }
        public bool Mine { get; set; }
        public List<ChanInfo> Chans { get; set; }
        public SrvInfo() { Chans = new List<ChanInfo>(); }
        [ScriptIgnore] public string Initial { get { return string.IsNullOrEmpty(Name) ? "?" : Name.Substring(0, 1).ToUpper(); } }
    }

    public class SMsg
    {
        public string Chan { get; set; }
        public string Nick { get; set; }
        public string Time { get; set; }
        public string Text { get; set; }
    }

    // ---------------------------------------------------------------- dados guardados no PC
    public static class Store
    {
        static readonly object lk = new object();
        public static List<Pub> Pubs = new List<Pub>();
        public static List<Playlist> Playlists = new List<Playlist>();
        public static List<SrvInfo> Hosted = new List<SrvInfo>();
        public static List<SrvInfo> Joined = new List<SrvInfo>();

        public static string Dir
        {
            get
            {
                string d = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "capimm-rust");
                Directory.CreateDirectory(d);
                return d;
            }
        }

        static JavaScriptSerializer Js() { var j = new JavaScriptSerializer(); j.MaxJsonLength = int.MaxValue; return j; }

        static T Load<T>(string name) where T : class, new()
        {
            try
            {
                string p = System.IO.Path.Combine(Dir, name);
                if (File.Exists(p))
                {
                    var o = Js().Deserialize<T>(File.ReadAllText(p, Encoding.UTF8));
                    if (o != null) return o;
                }
            }
            catch (Exception ex) { Util.Log(ex); }
            return new T();
        }

        static void Save(string name, object o)
        {
            lock (lk)
            {
                try { File.WriteAllText(System.IO.Path.Combine(Dir, name), Js().Serialize(o), new UTF8Encoding(false)); }
                catch (Exception ex) { Util.Log(ex); }
            }
        }

        public static void Init()
        {
            Pubs = Load<List<Pub>>("cmr.json");
            Playlists = Load<List<Playlist>>("playlists.json");
            Hosted = Load<List<SrvInfo>>("hosted.json");
            Joined = Load<List<SrvInfo>>("joined.json");
        }

        public static void SavePubs() { Save("cmr.json", Pubs); }
        public static void SavePlaylists() { Save("playlists.json", Playlists); }
        public static void SaveHosted() { Save("hosted.json", Hosted); }
        public static void SaveJoined() { Save("joined.json", Joined); }

        public static List<Pub> PubsSnapshot() { lock (lk) return new List<Pub>(Pubs); }

        public static Pub FindPub(string id)
        {
            lock (lk) { foreach (var p in Pubs) if (p.Id == id) return p; }
            return null;
        }

        public static void AddPub(Pub p) { lock (lk) Pubs.Add(p); SavePubs(); }
        public static void RemovePub(string id) { lock (lk) Pubs.RemoveAll(p => p.Id == id); SavePubs(); }
    }

    // ---------------------------------------------------------------- servidores (o PC do dono é o servidor)
    public static class GuildHost
    {
        class Sub { public Stream Ns; public string Nick; public string Srv; }
        static readonly List<Sub> subs = new List<Sub>();
        static readonly object lk = new object();
        static JavaScriptSerializer Js() { return new JavaScriptSerializer(); }

        public static string NewId() { return Guid.NewGuid().ToString("N").Substring(0, 8); }

        public static string Clean(string s, int max)
        {
            s = Util.Clean(s).Trim();
            if (s.Length > max) s = s.Substring(0, max);
            return s;
        }

        public static SrvInfo Find(string id)
        {
            lock (lk) { foreach (var s in Store.Hosted) if (s.Id == id) return s; }
            return null;
        }

        static ChanInfo FindChan(SrvInfo srv, string id)
        {
            lock (lk) { foreach (var c in srv.Chans) if (c.Id == id) return c; }
            return null;
        }

        public static SrvInfo Create(string name, string owner)
        {
            var s = new SrvInfo { Id = NewId(), Name = Clean(name, 32), Owner = Clean(owner, 24), Mine = true, Addr = "127.0.0.1:7878" };
            s.Chans.Add(new ChanInfo { Id = "geral", Name = "geral", Type = "chat" });
            s.Chans.Add(new ChanInfo { Id = "avisos", Name = "avisos", Type = "aviso" });
            lock (lk) Store.Hosted.Add(s);
            Store.SaveHosted();
            return s;
        }

        static string LogPath(string srv, string chan)
        {
            string d = System.IO.Path.Combine(Store.Dir, "guilds", srv);
            Directory.CreateDirectory(d);
            return System.IO.Path.Combine(d, chan + ".log");
        }

        static void Broadcast(string srv, string line)
        {
            lock (lk)
            {
                var dead = new List<Sub>();
                foreach (var s in subs)
                {
                    if (s.Srv != srv) continue;
                    try { Wire.Send(s.Ns, line); } catch { dead.Add(s); }
                }
                foreach (var d in dead) subs.Remove(d);
            }
        }

        static void Reply(Sub s, string line) { lock (lk) Wire.Send(s.Ns, line); }

        static void Presence(string srv)
        {
            string names;
            lock (lk)
            {
                var l = new List<string>();
                foreach (var s in subs) if (s.Srv == srv && !l.Contains(s.Nick)) l.Add(s.Nick);
                names = string.Join(",", l.ToArray());
            }
            Broadcast(srv, "PRES\t" + names);
        }

        public static void Serve(Stream ns, Stream rd, string srvId, string nick, bool owner)
        {
            var srv = Find(srvId);
            if (srv == null) { Wire.Send(ns, "ERR\tservidor"); return; }
            var me = new Sub { Ns = ns, Nick = Clean(nick, 24), Srv = srvId };
            if (me.Nick.Length == 0) me.Nick = "visitante";
            lock (lk) subs.Add(me);
            try
            {
                Reply(me, "OK\t" + (owner ? "1" : "0"));
                string meta;
                lock (lk) meta = Js().Serialize(srv);
                Reply(me, "SRV\t" + meta);
                Presence(srvId);
                string line;
                while ((line = Wire.ReadLine(rd)) != null)
                {
                    string[] p = line.Split(new char[] { '\t' }, 3);
                    if (p[0] == "SAY" && p.Length > 2)
                    {
                        var ch = FindChan(srv, p[1]);
                        string text = Clean(p[2], 2000);
                        if (ch == null || text.Length == 0) continue;
                        if (ch.Type == "aviso" && !owner) { Reply(me, "ERR\tSó o dono pode postar neste canal"); continue; }
                        long ticks = DateTime.UtcNow.Ticks;
                        try { File.AppendAllText(LogPath(srvId, ch.Id), ticks + "\t" + me.Nick + "\t" + text + "\n", new UTF8Encoding(false)); } catch { }
                        Broadcast(srvId, "MSG\t" + ch.Id + "\t" + me.Nick + "\t" + ticks + "\t" + text);
                    }
                    else if (p[0] == "HIST" && p.Length > 2)
                    {
                        var ch = FindChan(srv, p[1]);
                        if (ch == null) continue;
                        int n;
                        if (!int.TryParse(p[2], out n) || n <= 0 || n > 500) n = 100;
                        string path = LogPath(srvId, ch.Id);
                        if (File.Exists(path))
                        {
                            string[] all = File.ReadAllLines(path, Encoding.UTF8);
                            for (int i = Math.Max(0, all.Length - n); i < all.Length; i++)
                            {
                                string[] q = all[i].Split(new char[] { '\t' }, 3);
                                if (q.Length < 3) continue;
                                Reply(me, "HMSG\t" + ch.Id + "\t" + q[1] + "\t" + q[0] + "\t" + q[2]);
                            }
                        }
                        Reply(me, "HEND\t" + ch.Id);
                    }
                    else if (p[0] == "NEWCHAN" && p.Length > 2)
                    {
                        if (!owner) { Reply(me, "ERR\tSó o dono cria canais"); continue; }
                        var sb = new StringBuilder();
                        foreach (char c in Clean(p[1], 24).ToLowerInvariant())
                        {
                            if (char.IsLetterOrDigit(c) || c == '-' || c == '_') sb.Append(c);
                            else if (c == ' ') sb.Append('-');
                        }
                        string nm = sb.ToString();
                        if (nm.Length == 0) continue;
                        string type = p[2] == "aviso" ? "aviso" : "chat";
                        bool created = false;
                        lock (lk)
                        {
                            if (FindChan(srv, nm) == null) { srv.Chans.Add(new ChanInfo { Id = nm, Name = nm, Type = type }); created = true; }
                        }
                        if (created)
                        {
                            Store.SaveHosted();
                            string m2;
                            lock (lk) m2 = Js().Serialize(srv);
                            Broadcast(srvId, "SRV\t" + m2);
                        }
                    }
                }
            }
            finally
            {
                lock (lk) subs.Remove(me);
                Presence(srvId);
            }
        }
    }

    public class GuildClient
    {
        TcpClient c;
        Stream ns;
        volatile bool closed;
        public Action<SrvInfo, bool> OnMeta;
        public Action<SMsg, bool> OnMsg;
        public Action<string[]> OnPres;
        public Action<string> OnErr;
        public Action OnClosed;

        static string FmtTime(string ticks)
        {
            long t;
            if (!long.TryParse(ticks, out t)) return "";
            var d = new DateTime(t, DateTimeKind.Utc).ToLocalTime();
            return d.Date == DateTime.Now.Date ? d.ToString("HH:mm") : d.ToString("dd/MM HH:mm");
        }

        public void Connect(string addr, string srvId, string nick)
        {
            c = Client.Open(addr);
            ns = c.GetStream();
            var rd = new BufferedStream(ns, 8192);
            Wire.Send(ns, "SUB\t" + srvId + "\t" + Util.Clean(nick));
            string h = Wire.ReadLine(rd);
            if (h == null || !h.StartsWith("OK"))
            {
                Close();
                throw new Exception(h != null && h.Contains("servidor") ? "servidor não encontrado (o dono está online?)" : "não consegui entrar");
            }
            bool owner = h.EndsWith("1");
            var t = new Thread(() =>
            {
                try
                {
                    string l;
                    while ((l = Wire.ReadLine(rd)) != null) HandleLine(l, owner);
                }
                catch { }
                if (!closed && OnClosed != null) OnClosed();
            });
            t.IsBackground = true;
            t.Start();
        }

        void HandleLine(string l, bool owner)
        {
            if (closed) return;
            if (l.StartsWith("SRV\t"))
            {
                var m = new JavaScriptSerializer().Deserialize<SrvInfo>(l.Substring(4));
                if (OnMeta != null && m != null) OnMeta(m, owner);
                return;
            }
            string[] p = l.Split(new char[] { '\t' }, 5);
            if ((p[0] == "MSG" || p[0] == "HMSG") && p.Length >= 5)
            {
                var m = new SMsg { Chan = p[1], Nick = p[2], Time = FmtTime(p[3]), Text = p[4] };
                if (OnMsg != null) OnMsg(m, p[0] == "HMSG");
            }
            else if (p[0] == "PRES")
            {
                string names = p.Length > 1 ? p[1] : "";
                if (OnPres != null) OnPres(names.Length == 0 ? new string[0] : names.Split(','));
            }
            else if (p[0] == "ERR" && p.Length > 1)
            {
                if (OnErr != null) OnErr(p[1]);
            }
        }

        void Send(string line) { try { if (ns != null) Wire.Send(ns, line); } catch { } }
        public void Say(string chan, string text) { Send("SAY\t" + chan + "\t" + Util.Clean(text)); }
        public void Hist(string chan, int n) { Send("HIST\t" + chan + "\t" + n); }
        public void NewChan(string name, string type) { Send("NEWCHAN\t" + Util.Clean(name) + "\t" + type); }
        public void Close() { closed = true; try { if (c != null) c.Close(); } catch { } }
    }

    // ---------------------------------------------------------------- CM-R: biblioteca feita pelos PCs de todos
    public static class Cmr
    {
        static string Get(Dictionary<string, object> d, string k)
        {
            object v;
            return d.TryGetValue(k, out v) && v != null ? v.ToString() : "";
        }

        public static List<Item> Catalog(string addr)
        {
            using (var c = Client.Open(addr))
            {
                c.ReceiveTimeout = 6000;
                var ns = c.GetStream();
                var rd = new BufferedStream(ns, 8192);
                Wire.Send(ns, "CAT");
                string h = Wire.ReadLine(rd);
                if (h == null || !h.StartsWith("OK")) throw new Exception("sem catálogo");
                int n = int.Parse(h.Split('\t')[1]);
                var res = new List<Item>();
                var js = new JavaScriptSerializer();
                for (int i = 0; i < n && i < 2000; i++)
                {
                    string l = Wire.ReadLine(rd);
                    if (l == null) break;
                    var d = js.DeserializeObject(l) as Dictionary<string, object>;
                    if (d == null) continue;
                    string id = Get(d, "id");
                    if (id.Length == 0) continue;
                    string owner = Get(d, "owner");
                    res.Add(new Item { Name = Get(d, "title"), Artist = Get(d, "artist"), Tag = "CM-R · " + owner, Source = "CM-R", Full = true, Addr = addr, PubId = id, Owner = owner, Ext = Get(d, "ext") });
                }
                return res;
            }
        }

        public static List<string> Peers(string addr)
        {
            using (var c = Client.Open(addr))
            {
                c.ReceiveTimeout = 5000;
                var ns = c.GetStream();
                var rd = new BufferedStream(ns, 4096);
                Wire.Send(ns, "PEERS");
                string h = Wire.ReadLine(rd);
                var res = new List<string>();
                if (h == null || !h.StartsWith("OK")) return res;
                int n = int.Parse(h.Split('\t')[1]);
                for (int i = 0; i < n && i < 200; i++)
                {
                    string l = Wire.ReadLine(rd);
                    if (l == null) break;
                    res.Add(l.Trim());
                }
                return res;
            }
        }

        public static string Lyrics(string addr, string id)
        {
            using (var c = Client.Open(addr))
            {
                c.ReceiveTimeout = 8000;
                var ns = c.GetStream();
                var rd = new BufferedStream(ns, 8192);
                Wire.Send(ns, "PLYR\t" + id);
                string h = Wire.ReadLine(rd);
                if (h == null || !h.StartsWith("OK")) return null;
                int len = int.Parse(h.Split('\t')[1]);
                if (len <= 0 || len > 2000000) return null;
                var buf = new byte[len];
                int got = 0;
                while (got < len)
                {
                    int r = rd.Read(buf, got, len - got);
                    if (r <= 0) break;
                    got += r;
                }
                return Encoding.UTF8.GetString(buf, 0, got);
            }
        }

        public static void Download(string addr, string id, string dest)
        {
            using (var c = Client.Open(addr))
            {
                c.ReceiveTimeout = 20000;
                var ns = c.GetStream();
                var rd = new BufferedStream(ns, 65536);
                Wire.Send(ns, "PGET\t" + id);
                string h = Wire.ReadLine(rd);
                if (h == null || !h.StartsWith("OK")) throw new Exception("a música não está mais disponível (o dono está online?)");
                long size = long.Parse(h.Split('\t')[1]);
                string tmp = dest + ".part";
                using (var fs = File.Create(tmp))
                {
                    var buf = new byte[65536];
                    long got = 0;
                    while (got < size)
                    {
                        int n = rd.Read(buf, 0, (int)Math.Min(buf.Length, size - got));
                        if (n <= 0) throw new IOException("a conexão caiu");
                        fs.Write(buf, 0, n);
                        got += n;
                    }
                }
                if (File.Exists(dest)) File.Delete(dest);
                File.Move(tmp, dest);
            }
        }
    }
}
