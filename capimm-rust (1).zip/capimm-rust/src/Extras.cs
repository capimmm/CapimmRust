using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Pulse
{
    public class LrcLine { public double T; public string S; }

    // fontes extras (músicas completas), letras sincronizadas e cores da capa
    public static class Extra
    {
        const string UA = "capimm-rust/3.1 (https://github.com/capimmm)";
        public const string JamKey = "81f58931"; // client_id público do app capimm-rust (Jamendo)
        static string audiusHost;
        static List<string> audiusHosts = new List<string>();
        static readonly Regex TagRx = new Regex(@"\[(\d+):(\d+(?:\.\d+)?)\]");

        static string Get(string url)
        {
            var r = (HttpWebRequest)WebRequest.Create(url);
            r.UserAgent = UA; r.Timeout = 9000; r.ReadWriteTimeout = 9000;
            using (var resp = r.GetResponse())
            using (var s = resp.GetResponseStream())
            using (var sr = new StreamReader(s, Encoding.UTF8))
                return sr.ReadToEnd();
        }

        static JavaScriptSerializer Js() { var j = new JavaScriptSerializer(); j.MaxJsonLength = int.MaxValue; return j; }
        static System.Collections.IEnumerable Arr(object o) { return o as System.Collections.IEnumerable; }

        static string S(Dictionary<string, object> d, string k)
        {
            object v;
            if (d != null && d.TryGetValue(k, out v) && v != null) return v.ToString();
            return "";
        }

        static Dictionary<string, object> D(Dictionary<string, object> d, string k)
        {
            object v;
            if (d != null && d.TryGetValue(k, out v)) return v as Dictionary<string, object>;
            return null;
        }

        // ---------------- Audius: músicas completas de artistas independentes (grátis)
        static string Host()
        {
            if (audiusHost != null) return audiusHost;
            string h = "https://discoveryprovider.audius.co";
            audiusHosts = new List<string>();
            try
            {
                var root = Js().DeserializeObject(Get("https://api.audius.co")) as Dictionary<string, object>;
                object dv;
                if (root != null && root.TryGetValue("data", out dv))
                {
                    var a = Arr(dv);
                    if (a != null)
                        foreach (object o in a)
                        {
                            string s = o as string;
                            if (string.IsNullOrEmpty(s)) continue;
                            if (audiusHosts.Count == 0) h = s;
                            if (audiusHosts.Count < 4) audiusHosts.Add(s.TrimEnd('/'));
                        }
                }
            }
            catch { }
            audiusHost = h.TrimEnd('/');
            if (audiusHosts.Count == 0) audiusHosts.Add(audiusHost);
            return audiusHost;
        }

        public static List<Item> Audius(string q)
        {
            string host = Host();
            string url = q.Length == 0
                ? host + "/v1/tracks/trending?limit=20&app_name=capimm-rust"
                : host + "/v1/tracks/search?limit=20&app_name=capimm-rust&query=" + Uri.EscapeDataString(q);
            var res = new List<Item>();
            var root = Js().DeserializeObject(Get(url)) as Dictionary<string, object>;
            object dv;
            if (root == null || !root.TryGetValue("data", out dv)) return res;
            var arr = Arr(dv);
            if (arr == null) return res;
            foreach (object o in arr)
            {
                var d = o as Dictionary<string, object>;
                if (d == null) continue;
                string id = S(d, "id");
                if (id.Length == 0) continue;
                var art = D(d, "artwork");
                string small = S(art, "150x150"), big = S(art, "480x480");
                var alts = new List<string>();
                foreach (string hh in audiusHosts) if (hh != host) alts.Add(hh + "/v1/tracks/" + id + "/stream?app_name=capimm-rust");
                alts.Add("https://api.audius.co/v1/tracks/" + id + "/stream?app_name=capimm-rust");
                res.Add(new Item
                {
                    Alts = alts,
                    Name = S(d, "title"),
                    Artist = S(D(d, "user"), "name"),
                    Cover = small.Length == 0 ? null : small,
                    CoverBig = big.Length == 0 ? null : big,
                    Url = host + "/v1/tracks/" + id + "/stream?app_name=capimm-rust",
                    Tag = "completa", Source = "Audius", Full = true
                });
            }
            return res;
        }

        // ---------------- Jamendo: músicas completas livres (precisa de chave grátis)
        public static List<Item> Jamendo(string q, string key)
        {
            var res = new List<Item>();
            if (string.IsNullOrEmpty(key)) return res;
            string url = "https://api.jamendo.com/v3.0/tracks/?client_id=" + Uri.EscapeDataString(key) + "&format=json&limit=20&audioformat=mp32&imagesize=300"
                + (q.Length == 0 ? "&order=popularity_week" : "&search=" + Uri.EscapeDataString(q));
            var root = Js().DeserializeObject(Get(url)) as Dictionary<string, object>;
            object dv;
            if (root == null || !root.TryGetValue("results", out dv)) return res;
            var arr = Arr(dv);
            if (arr == null) return res;
            foreach (object o in arr)
            {
                var d = o as Dictionary<string, object>;
                if (d == null) continue;
                string audio = S(d, "audio"), img = S(d, "image");
                if (audio.Length == 0) continue;
                var jalts = new List<string>();
                if (audio.Contains("mp32")) jalts.Add(audio.Replace("mp32", "mp31"));
                string jid = S(d, "id");
                if (jid.Length > 0) jalts.Add("https://prod-1.storage.jamendo.com/?trackid=" + jid + "&format=mp31");
                string jdl = S(d, "audiodownload");
                if (jdl.Length > 0) jalts.Add(jdl);
                res.Add(new Item { Alts = jalts, Name = S(d, "name"), Artist = S(d, "artist_name"), Cover = img.Length == 0 ? null : img, CoverBig = img.Length == 0 ? null : img, Url = audio, Tag = "completa", Source = "Jamendo", Full = true });
            }
            return res;
        }

        // ---------------- letras (LRCLIB, com tempo quando disponível)
        static string CleanTitle(string t)
        {
            t = Regex.Replace(t ?? "", @"\([^)]*\)|\[[^\]]*\]", " ");
            t = Regex.Replace(t, @"\s+-\s+(remaster|remix|ao vivo|live|version).*$", "", RegexOptions.IgnoreCase);
            return Regex.Replace(t, @"\s+", " ").Trim();
        }

        public static List<LrcLine> ParseLrc(string lrc)
        {
            var r = new List<LrcLine>();
            foreach (string raw in lrc.Replace("\r", "").Split('\n'))
            {
                var ms = TagRx.Matches(raw);
                if (ms.Count == 0) continue;
                string text = TagRx.Replace(raw, "").Trim();
                foreach (Match m in ms)
                    r.Add(new LrcLine { T = int.Parse(m.Groups[1].Value) * 60 + double.Parse(m.Groups[2].Value, System.Globalization.CultureInfo.InvariantCulture), S = text });
            }
            r.Sort((a, b) => a.T.CompareTo(b.T));
            return r;
        }

        public static void FromText(string text, out List<LrcLine> synced, out string plain)
        {
            var s = ParseLrc(text);
            if (s.Count > 0) { synced = s; plain = null; }
            else { synced = null; plain = text; }
        }

        public static void Lyrics(string title, string artist, out List<LrcLine> synced, out string plain)
        {
            synced = null; plain = null;
            string t = CleanTitle(title);
            string a = CleanTitle(artist);
            string[] urls = a.Length > 0
                ? new[] { "https://lrclib.net/api/search?track_name=" + Uri.EscapeDataString(t) + "&artist_name=" + Uri.EscapeDataString(a),
                          "https://lrclib.net/api/search?q=" + Uri.EscapeDataString(t + " " + a),
                          "https://lrclib.net/api/search?track_name=" + Uri.EscapeDataString(t) }
                : new[] { "https://lrclib.net/api/search?q=" + Uri.EscapeDataString(t) };
            foreach (string u in urls)
            {
                var arr = Arr(Js().DeserializeObject(Get(u)));
                if (arr == null) continue;
                foreach (object o in arr)
                {
                    var d = o as Dictionary<string, object>;
                    if (d == null) continue;
                    string sl = S(d, "syncedLyrics"), pl = S(d, "plainLyrics");
                    if (sl.Length > 0)
                    {
                        var tmp = ParseLrc(sl);
                        if (tmp.Count > 0) { synced = tmp; plain = pl; return; }
                    }
                    if (plain == null && pl.Length > 0) plain = pl;
                }
                if (plain != null) return;
            }
        }

        // ---------------- capa + paleta de cores (para o fundo dinâmico)
        public static BitmapImage LoadImage(string url, int decodeW, out Color[] palette)
        {
            byte[] data;
            string cp = "";
            try
            {
                string cd = Path.Combine(Store.Dir, "cache");
                Directory.CreateDirectory(cd);
                cp = Path.Combine(cd, "cov" + ((uint)url.GetHashCode()).ToString("x8"));
            }
            catch { }
            if (cp.Length > 0 && File.Exists(cp)) data = File.ReadAllBytes(cp);
            else
            {
                using (var wc = new WebClient()) { wc.Headers["User-Agent"] = UA; data = wc.DownloadData(url); }
                if (cp.Length > 0) { try { File.WriteAllBytes(cp, data); } catch { } }
            }
            palette = Palette(data);
            var bi = new BitmapImage();
            bi.BeginInit();
            bi.CacheOption = BitmapCacheOption.OnLoad;
            bi.DecodePixelWidth = decodeW;
            bi.StreamSource = new MemoryStream(data);
            bi.EndInit();
            bi.Freeze();
            return bi;
        }

        static double HueOf(double r, double g, double b)
        {
            double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b)), d = max - min;
            if (d < 1e-6) return 0;
            double h;
            if (max == r) h = ((g - b) / d) % 6;
            else if (max == g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h *= 60;
            return h < 0 ? h + 360 : h;
        }

        public static Color Hsv(double h, double s, double v)
        {
            h = ((h % 360) + 360) % 360;
            double cc = v * s, x = cc * (1 - Math.Abs((h / 60) % 2 - 1)), m = v - cc, r, g, b;
            if (h < 60) { r = cc; g = x; b = 0; }
            else if (h < 120) { r = x; g = cc; b = 0; }
            else if (h < 180) { r = 0; g = cc; b = x; }
            else if (h < 240) { r = 0; g = x; b = cc; }
            else if (h < 300) { r = x; g = 0; b = cc; }
            else { r = cc; g = 0; b = x; }
            return Color.FromRgb((byte)((r + m) * 255), (byte)((g + m) * 255), (byte)((b + m) * 255));
        }

        // 3 cores distintas da capa (domina o matiz mais forte; as outras vêm de matizes diferentes)
        public static Color[] Palette(byte[] data)
        {
            var bi = new BitmapImage();
            bi.BeginInit();
            bi.CacheOption = BitmapCacheOption.OnLoad;
            bi.DecodePixelWidth = 40;
            bi.StreamSource = new MemoryStream(data);
            bi.EndInit();
            bi.Freeze();
            var fc = new FormatConvertedBitmap(bi, PixelFormats.Bgra32, null, 0);
            int w = fc.PixelWidth, h = fc.PixelHeight;
            var px = new byte[w * h * 4];
            fc.CopyPixels(px, w * 4, 0);
            var R = new double[12]; var G = new double[12]; var B = new double[12]; var Wt = new double[12];
            double tot = 0;
            for (int i = 0; i + 3 < px.Length; i += 4)
            {
                double b = px[i], g = px[i + 1], r = px[i + 2];
                double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
                if (max < 30) continue;
                double sat = (max - min) / max;
                if (sat < 0.15) continue;
                double wt = sat * sat * (0.25 + max / 255.0);
                int bin = ((int)(HueOf(r, g, b) / 30.0)) % 12;
                R[bin] += r * wt; G[bin] += g * wt; B[bin] += b * wt; Wt[bin] += wt; tot += wt;
            }
            if (tot < 1e-6) return new[] { Color.FromRgb(235, 235, 235), Color.FromRgb(190, 190, 205), Color.FromRgb(150, 150, 175) };
            var picks = new List<int>();
            for (int n = 0; n < 3; n++)
            {
                int best = -1; double bw = 0;
                for (int k = 0; k < 12; k++)
                {
                    if (Wt[k] <= bw) continue;
                    bool ok = true;
                    foreach (int p in picks) { int d = Math.Abs(p - k); d = Math.Min(d, 12 - d); if (d < 2) ok = false; }
                    if (ok) { best = k; bw = Wt[k]; }
                }
                if (best < 0) break;
                if (picks.Count > 0 && bw < Wt[picks[0]] * 0.1) break;
                picks.Add(best);
            }
            var res = new List<Color>();
            foreach (int p in picks)
            {
                double rr = R[p] / Wt[p], gg = G[p] / Wt[p], bb = B[p] / Wt[p];
                double mx = Math.Max(rr, Math.Max(gg, bb)), mn = Math.Min(rr, Math.Min(gg, bb));
                double sat = mx < 1 ? 0 : (mx - mn) / mx;
                res.Add(Hsv(HueOf(rr, gg, bb), Math.Max(0.55, Math.Min(0.95, sat * 1.1)), 0.8));
            }
            double baseHue = HueOf(res[0].R, res[0].G, res[0].B);
            while (res.Count < 3) res.Add(Hsv(baseHue + 45 * res.Count, 0.65, 0.8));
            return res.ToArray();
        }

        public static Color[] NamePalette(string s)
        {
            int hh = 17;
            foreach (char c in s ?? "") hh = hh * 31 + c;
            double hue = (hh & 0x7FFFFFFF) % 360;
            return new[] { Hsv(hue, 0.65, 0.8), Hsv(hue + 45, 0.6, 0.78), Hsv(hue + 95, 0.55, 0.78) };
        }
    }

    // ícones (geometrias já centralizadas opticamente)
    public static class Geo
    {
        public const string Play = "M5,0 L23,11 L5,22 Z";
        public const string Pause = "M2,0 L8,0 L8,22 L2,22 Z M14,0 L20,0 L20,22 L14,22 Z";
        public const string Prev = "M0,0 L3,0 L3,16 L0,16 Z M17,0 L5,8 L17,16 Z";
        public const string Next = "M14,0 L17,0 L17,16 L14,16 Z M0,0 L12,8 L0,16 Z";
    }
}
